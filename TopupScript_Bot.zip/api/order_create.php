<?php
require_once __DIR__ . '/../common/config.php';
if (!current_user()) json_err('Login required', 401);

$d = json_input();
if (!csrf_check($d['_csrf'] ?? '')) json_err('Bad CSRF', 403);

$me = current_user();
$catId  = (int)($d['cat_id'] ?? 0);
$prodId = (int)($d['product_id'] ?? 0);
$method = $d['payment_method'] ?? '';
$playerUid = trim((string)($d['player_uid'] ?? ''));
$zoneId    = trim((string)($d['zone_id'] ?? ''));

$stmt = db()->prepare("SELECT * FROM categories WHERE id = ? AND status='active'");
$stmt->execute([$catId]); $cat = $stmt->fetch();
$stmt = db()->prepare("SELECT * FROM products WHERE id = ? AND cat_id = ? AND status='active'");
$stmt->execute([$prodId, $catId]); $prod = $stmt->fetch();
if (!$cat || !$prod) json_err('Invalid product');
if ($cat['type'] === 'uid' && !$playerUid) json_err('Player UID required');

$amount = (float)$prod['price'];
$orderCode = gen_txn('ORD');

$pdo = db();
$pdo->beginTransaction();
try {
    if ($method === 'wallet') {
        // Lock check (simple)
        $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$me['id']]);
        $bal = (float)$stmt->fetchColumn();
        if ($bal < $amount) { $pdo->rollBack(); json_err('Insufficient wallet balance'); }

        $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")
            ->execute([$amount, $me['id']]);

        $pdo->prepare("INSERT INTO orders
            (order_code, user_id, cat_id, product_id, quantity, total_amount, player_uid, zone_id, payment_method, status)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?, 'wallet', 'pending')")
            ->execute([$orderCode, $me['id'], $catId, $prodId, $amount, $playerUid ?: null, $zoneId ?: null]);
        $orderId = (int)$pdo->lastInsertId();

        $pdo->prepare("INSERT INTO transactions (user_id, type, amount, note, ref_id) VALUES (?, 'order', ?, ?, ?)")
            ->execute([$me['id'], -$amount, 'Order ' . $orderCode, $orderCode]);

        // Try auto-fulfill from redeem_codes
        $rc = $pdo->prepare("SELECT * FROM redeem_codes WHERE cat_id = ? AND product_id = ? AND status = 'unused' LIMIT 1");
        $rc->execute([$catId, $prodId]);
        $code = $rc->fetch();
        if ($code) {
            $pdo->prepare("UPDATE redeem_codes SET status='used', assigned_order_id=?, used_at=CURRENT_TIMESTAMP WHERE id=?")
                ->execute([$orderId, $code['id']]);
            $pdo->prepare("INSERT INTO order_codes (order_id, code_id, code) VALUES (?, ?, ?)")
                ->execute([$orderId, $code['id'], $code['code']]);
            $pdo->prepare("UPDATE orders SET status='completed' WHERE id=?")->execute([$orderId]);
        }
        $pdo->commit();
        json_ok('Order placed', ['order_code'=>$orderCode]);
    }
    elseif ($method === 'manual') {
        $pmId = (int)($d['payment_method_id'] ?? 0);
        $sn = trim((string)($d['sender_number'] ?? ''));
        $tx = trim((string)($d['trx_id'] ?? ''));
        if (!$pmId || !$sn || !$tx) { $pdo->rollBack(); json_err('Missing payment details'); }
        $pdo->prepare("INSERT INTO orders
            (order_code, user_id, cat_id, product_id, quantity, total_amount, player_uid, zone_id, payment_method, payment_method_id, sender_number, trx_id, status)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?, 'manual', ?, ?, ?, 'pending')")
            ->execute([$orderCode, $me['id'], $catId, $prodId, $amount, $playerUid ?: null, $zoneId ?: null, $pmId, $sn, $tx]);
        $pdo->commit();
        json_ok('Order submitted — pending admin approval', ['order_code'=>$orderCode]);
    } else {
        $pdo->rollBack(); json_err('Invalid payment method');
    }
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    json_err('Server error: ' . $e->getMessage(), 500);
}
