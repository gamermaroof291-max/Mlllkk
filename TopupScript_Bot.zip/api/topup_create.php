<?php
require_once __DIR__ . '/../common/config.php';
if (!current_user()) json_err('Login required', 401);

$d = json_input();
if (!csrf_check($d['_csrf'] ?? '')) json_err('Bad CSRF', 403);

$me = current_user();
$amount = (float)($d['amount'] ?? 0);
$pmId = (int)($d['method_id'] ?? 0);
$sn = trim((string)($d['sender_number'] ?? ''));
$tx = trim((string)($d['trx_id'] ?? ''));

$min = (float)setting('min_addmoney', 20);
$max = (float)setting('max_addmoney', 50000);

if ($amount < $min || $amount > $max) json_err("Amount must be between $min and $max");
if (!$pmId) json_err('Choose a payment method');
if (!$sn || !$tx) json_err('Sender number and TxnID are required');

db()->prepare("INSERT INTO wallet_topup (user_id, amount, method_id, sender_number, trx_id, status) VALUES (?, ?, ?, ?, ?, 'pending')")
    ->execute([$me['id'], $amount, $pmId, $sn, $tx]);
json_ok('Top-up request submitted — pending admin approval');
