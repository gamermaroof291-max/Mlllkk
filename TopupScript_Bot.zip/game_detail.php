<?php
require_once __DIR__ . '/common/config.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM categories WHERE id = ? AND status='active'");
$stmt->execute([$id]);
$g = $stmt->fetch();
if (!$g) { header('Location: ' . site_url('index.php')); exit; }

$pStmt = db()->prepare("SELECT * FROM products WHERE cat_id = ? AND status='active' ORDER BY sort_order ASC, price ASC");
$pStmt->execute([$id]);
$products = $pStmt->fetchAll();

$pageTitle = $g['name'] . ' — ' . setting('site_name');
$me = current_user();
require __DIR__ . '/common/header.php';
?>

<!-- Game info card -->
<div class="card p-3 mb-4 flex items-center gap-3">
  <img src="<?= e($g['image'] ?: 'https://placehold.co/200x200') ?>" alt="" class="w-16 h-16 rounded-lg object-cover flex-shrink-0">
  <div class="min-w-0">
    <h1 class="font-extrabold text-[16px] text-ink leading-tight"><?= e($g['name']) ?></h1>
    <div class="text-xs text-muted mt-0.5"><?= e($g['section'] ?: 'Game') ?> / Top up</div>
  </div>
</div>

<!-- Step 1: Select Recharge -->
<div class="card p-4 mb-4">
  <div class="section-title mb-4"><span class="step-num">1</span>Select Recharge</div>
  <?php if (!$products): ?>
    <div class="text-center text-muted text-sm py-3">No packs available right now.</div>
  <?php else: ?>
  <div class="grid grid-cols-2 gap-2.5" id="productGrid">
    <?php foreach ($products as $p): ?>
      <button type="button" class="pack" data-id="<?= (int)$p['id'] ?>" data-price="<?= (float)$p['price'] ?>" data-name="<?= e($p['name']) ?>">
        <span class="dot"><i class="fa-solid fa-check"></i></span>
        <span class="name flex-1 text-left ml-1"><?= e($p['name']) ?></span>
        <span class="price"><?= number_format((float)$p['price'],0) ?> TK</span>
      </button>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Step 2: Account Info -->
<?php if ($g['type'] === 'uid'): ?>
<div class="card p-4 mb-4">
  <div class="section-title mb-3"><span class="step-num">2</span>Account Info</div>
  <label class="block text-[13px] font-bold text-ink mb-1.5">Player Id</label>
  <input id="playerUid" class="input" inputmode="numeric" placeholder="Player Id">
  <?php if ((int)$g['zone_required'] === 1): ?>
    <label class="block text-[13px] font-bold text-ink mb-1.5 mt-3">Zone Id</label>
    <input id="zoneId" class="input" inputmode="numeric" placeholder="Zone Id">
  <?php endif; ?>
</div>
<?php else: ?>
<div class="card p-4 mb-4">
  <div class="section-title mb-3"><span class="step-num">2</span>Voucher</div>
  <p class="text-sm text-muted">This product is delivered as a <b class="text-ink">voucher code</b> after payment confirmation. No player ID required.</p>
</div>
<?php endif; ?>

<!-- Step 3: Select payment option -->
<div class="card p-4 mb-4">
  <div class="section-title mb-4"><span class="step-num">3</span>Select one option</div>
  <div class="grid grid-cols-2 gap-3 mb-3">
    <button type="button" class="payopt" data-opt="wallet">
      <div class="body">
        <div class="text-center">
          <div class="w-14 h-10 mx-auto rounded-md bg-gradient-to-br from-[#F97316] to-[#EA580C] text-white text-xs font-extrabold flex items-center justify-center mb-1.5 px-2">CZ WALLET</div>
        </div>
      </div>
      <div class="label">Wallet Pay</div>
    </button>
    <button type="button" class="payopt" data-opt="manual">
      <div class="body">
        <div class="flex gap-1 items-center">
          <span class="w-9 h-9 rounded bg-[#E2136E] text-white text-[9px] font-bold flex items-center justify-center">bKash</span>
          <span class="w-9 h-9 rounded bg-[#F58220] text-white text-[9px] font-bold flex items-center justify-center">Nagad</span>
          <span class="w-9 h-9 rounded bg-[#8E2D89] text-white text-[8px] font-bold flex items-center justify-center">Rocket</span>
        </div>
      </div>
      <div class="label">Instant Pay</div>
    </button>
  </div>

  <div class="space-y-1.5 text-[12.5px]">
    <div class="flex items-center gap-2 text-muted">
      <i class="fa-solid fa-circle-info text-brand"></i>
      <span>আপনার অ্যাকাউন্ট ব্যালেন্স: <span class="font-bold text-brand"><?= e(setting('currency_symbol','৳')) ?> <?= $me ? number_format((float)$me['balance'],2) : '0.00' ?></span></span>
      <button onclick="location.reload()" class="ml-auto text-brand"><i class="fa-solid fa-arrows-rotate"></i></button>
    </div>
    <div class="flex items-center gap-2 text-muted">
      <i class="fa-solid fa-circle-info text-brand"></i>
      <span>প্রোডাক্ট কিনতে আপনার প্রয়োজন: <span id="needAmount" class="font-bold text-orange"><?= e(setting('currency_symbol','৳')) ?> 0</span></span>
    </div>
  </div>
</div>

<!-- Buy Now -->
<button id="continueBtn" class="btn-blue mb-5" disabled>Buy Now</button>

<!-- Rules -->
<?php $rules = $g['rules'] ?: setting('rules_text'); if ($rules): ?>
<div class="card p-4 mb-3">
  <h3 class="font-extrabold text-[15px] text-ink mb-2">Rules &amp; Conditions</h3>
  <div class="text-[13px] text-ink leading-[1.7] whitespace-pre-line"><?= e($rules) ?></div>
</div>
<?php endif; ?>

<form id="goForm" method="get" action="<?= e(site_url('instantpay.php')) ?>" class="hidden">
  <input type="hidden" name="cat_id" value="<?= (int)$g['id'] ?>">
  <input type="hidden" name="product_id" id="fProd">
  <input type="hidden" name="player_uid" id="fUid">
  <input type="hidden" name="zone_id" id="fZone">
  <input type="hidden" name="opt" id="fOpt">
</form>

<script>
(function(){
  var sel=null, selPrice=0, opt=null;
  var sym='<?= e(setting('currency_symbol','৳')) ?>';
  var packs=document.querySelectorAll('.pack');
  packs.forEach(function(c){
    c.addEventListener('click', function(){
      packs.forEach(x=>x.classList.remove('selected'));
      c.classList.add('selected');
      sel=c.dataset.id; selPrice=parseFloat(c.dataset.price);
      document.getElementById('needAmount').textContent = sym+' '+Math.round(selPrice);
      updateBtn();
    });
  });
  var opts=document.querySelectorAll('.payopt');
  opts.forEach(function(c){
    c.addEventListener('click', function(){
      opts.forEach(x=>x.classList.remove('selected'));
      c.classList.add('selected'); opt=c.dataset.opt; updateBtn();
    });
  });
  function updateBtn(){
    document.getElementById('continueBtn').disabled = !(sel && opt);
  }
  document.getElementById('continueBtn').addEventListener('click', function(){
    if (!sel) { window.czToast('Please select a recharge pack', 'warn'); return; }
    if (!opt) { window.czToast('Please select payment option', 'warn'); return; }
    var uid=document.getElementById('playerUid');
    var zone=document.getElementById('zoneId');
    if (uid && !uid.value.trim()) { window.czToast('Enter your Player Id', 'warn'); uid.focus(); return; }
    if (zone && !zone.value.trim()) { window.czToast('Enter your Zone Id', 'warn'); zone.focus(); return; }
    document.getElementById('fProd').value=sel;
    document.getElementById('fUid').value=uid?uid.value.trim():'';
    document.getElementById('fZone').value=zone?zone.value.trim():'';
    document.getElementById('fOpt').value=opt;
    document.getElementById('goForm').submit();
  });
})();
</script>
<?php require __DIR__ . '/common/footer.php'; ?>
