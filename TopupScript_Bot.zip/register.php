<?php
require_once __DIR__ . '/common/config.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) $err = 'Session expired.';
    else {
        $name = sanitize($_POST['name'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $pw = $_POST['password'] ?? '';
        $pw2 = $_POST['password2'] ?? '';
        if (!$name || !$phone || !$pw) $err = 'Name, phone & password required.';
        elseif (strlen($pw) < 6) $err = 'Password must be 6+ chars.';
        elseif ($pw !== $pw2) $err = 'Passwords do not match.';
        else {
            $stmt = db()->prepare("SELECT id FROM users WHERE phone=? OR (email IS NOT NULL AND email=?)");
            $stmt->execute([$phone, $email ?: '___none___']);
            if ($stmt->fetch()) $err = 'Phone or email already registered.';
            else {
                $h = password_hash($pw, PASSWORD_BCRYPT);
                $pin = (string)random_int(10000, 99999);
                db()->prepare("INSERT INTO users (name, phone, email, password, balance, support_pin, status) VALUES (?,?,?,?,?,?, 'active')")
                    ->execute([$name, $phone, $email ?: null, $h, 0, $pin]);
                $_SESSION['uid'] = (int)db()->lastInsertId();
                header('Location: ' . site_url('index.php')); exit;
            }
        }
    }
}
if (current_user()) { header('Location: ' . site_url('index.php')); exit; }
$pageTitle = 'Register — ' . setting('site_name');
require __DIR__ . '/common/header.php';
?>
<div class="card p-6 mt-2">
  <div class="text-center mb-5">
    <div class="inline-flex w-14 h-14 rounded-2xl text-white items-center justify-center text-xl font-extrabold shadow mb-3" style="background:linear-gradient(135deg,var(--c-brand),var(--c-navy));">CZ</div>
    <h1 class="text-xl font-extrabold text-ink">Create Account</h1>
    <p class="text-sm text-muted mt-1">Join Code Zen for instant game top-ups</p>
  </div>
  <?php if ($err): ?><div class="bg-rose-50 border border-rose-200 text-rose-700 rounded-lg p-3 mb-3 text-sm"><i class="fa-solid fa-circle-exclamation mr-1"></i><?= e($err) ?></div><?php endif; ?>
  <form method="post" class="space-y-3">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <div><label class="text-xs font-bold uppercase text-muted">Full name</label>
      <input name="name" class="input mt-1" required value="<?= e($_POST['name'] ?? '') ?>"></div>
    <div><label class="text-xs font-bold uppercase text-muted">Phone</label>
      <input name="phone" class="input mt-1" required value="<?= e($_POST['phone'] ?? '') ?>"></div>
    <div><label class="text-xs font-bold uppercase text-muted">Email (optional)</label>
      <input name="email" type="email" class="input mt-1" value="<?= e($_POST['email'] ?? '') ?>"></div>
    <div><label class="text-xs font-bold uppercase text-muted">Password</label>
      <input name="password" type="password" class="input mt-1" required></div>
    <div><label class="text-xs font-bold uppercase text-muted">Confirm password</label>
      <input name="password2" type="password" class="input mt-1" required></div>
    <button class="btn-blue mt-2"><i class="fa-solid fa-user-plus"></i>Create Account</button>
  </form>
  <div class="text-center mt-4 text-sm text-ink">Already have an account? <a href="<?= e(site_url('login.php')) ?>" class="text-brand font-bold">Login</a></div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>
