<?php
require_once __DIR__ . '/common/config.php';
require_login();
$me = current_user();

$stmt = db()->prepare("SELECT o.*, c.name AS game_name, c.image AS game_image, p.name AS product_name
  FROM orders o JOIN categories c ON c.id = o.cat_id JOIN products p ON p.id = o.product_id
  WHERE o.user_id = ? ORDER BY o.id DESC LIMIT 200");
$stmt->execute([$me['id']]);
$orders = $stmt->fetchAll();

$pageTitle = 'My Orders — ' . setting('site_name');
require __DIR__ . '/common/header.php';
?>

<div class="card mb-4">
  <div class="flex items-center justify-between p-4 border-b border-[#E5ECF5]">
    <h1 class="font-extrabold text-[16px] text-ink flex items-center gap-2"><i class="fa-solid fa-list text-brand"></i>My Orders</h1>
    <?php if ($orders): ?><span class="pill bg-brandSoft text-brand"><?= count($orders) ?> total</span><?php endif; ?>
  </div>

  <?php if (!$orders): ?>
    <div class="p-6 text-center">
      <div class="font-bold text-ink mb-3 text-[15px]">No order data found !</div>
      <a href="<?= e(site_url('index.php')) ?>" class="inline-block bg-[#DC2626] text-white text-xs font-extrabold tracking-wide px-5 py-2.5 rounded-md">ORDER NOW</a>
    </div>
  <?php endif; ?>
</div>

<?php if ($orders): ?>
<div class="space-y-3">
  <?php foreach ($orders as $o):
    $statusColors = [
      'pending'  => ['bg-amber-500','fa-clock','Pending'],
      'completed'=> ['bg-emerald-500','fa-circle-check','Completed'],
      'failed'   => ['bg-rose-500','fa-circle-xmark','Failed'],
      'cancelled'=> ['bg-slate-500','fa-ban','Cancelled'],
    ];
    $sc = $statusColors[$o['status']] ?? ['bg-slate-500','fa-circle','Unknown'];
  ?>
  <div class="card p-3.5">
    <div class="flex items-start gap-3">
      <img src="<?= e($o['game_image']) ?>" class="w-14 h-14 rounded-xl object-cover flex-shrink-0">
      <div class="flex-1 min-w-0">
        <div class="flex items-start justify-between gap-2">
          <div class="min-w-0">
            <div class="font-bold truncate text-sm text-ink"><?= e($o['game_name']) ?></div>
            <div class="text-[11px] text-muted truncate"><?= e($o['product_name']) ?></div>
          </div>
          <span class="pill <?= $sc[0] ?> text-white whitespace-nowrap"><i class="fa-solid <?= $sc[1] ?> mr-1"></i><?= $sc[2] ?></span>
        </div>
        <div class="mt-2 grid grid-cols-2 gap-2 text-[11px]">
          <div><span class="text-muted">Order:</span> <span class="font-mono font-semibold text-ink"><?= e($o['order_code']) ?></span></div>
          <div class="text-right"><span class="text-muted">Total:</span> <span class="font-bold text-brand"><?= format_money($o['total_amount']) ?></span></div>
          <?php if ($o['player_uid']): ?><div><span class="text-muted">UID:</span> <span class="font-mono text-ink"><?= e($o['player_uid']) ?></span></div><?php endif; ?>
          <div class="text-right text-muted"><?= time_ago($o['created_at']) ?></div>
        </div>
        <?php if ($o['status'] === 'completed'):
          $codes = db()->prepare("SELECT code FROM order_codes WHERE order_id = ?");
          $codes->execute([$o['id']]); $cs = $codes->fetchAll(PDO::FETCH_COLUMN); ?>
          <?php if ($cs): ?>
            <div class="mt-2 bg-emerald-50 border border-emerald-200 rounded-lg p-2.5">
              <div class="text-xs font-bold text-emerald-700 mb-1"><i class="fa-solid fa-key mr-1"></i>Your Code(s)</div>
              <?php foreach ($cs as $c): ?>
                <div class="flex items-center justify-between gap-2 text-xs font-mono bg-white rounded px-2 py-1 mt-1">
                  <span class="truncate text-ink"><?= e($c) ?></span>
                  <button onclick="navigator.clipboard.writeText('<?= e($c) ?>'); window.czToast('Copied','success');" class="text-brand"><i class="fa-solid fa-copy"></i></button>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        <?php endif; ?>
        <?php if ($o['admin_note']): ?>
          <div class="mt-2 text-[11px] bg-amber-50 text-amber-800 border border-amber-200 rounded-lg p-2"><i class="fa-solid fa-message mr-1"></i><?= e($o['admin_note']) ?></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<?php require __DIR__ . '/common/footer.php'; ?>
