<?php
// Router for PHP built-in server (Replit preview only).
// On Apache (InfinityFree / ProFreeHost), .htaccess and DirectoryIndex handle routing.
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Serve static files directly
if ($uri !== '/' && file_exists(__DIR__ . $uri)) {
    return false;
}

// Directory -> index.php
if (is_dir(__DIR__ . rtrim($uri, '/'))) {
    $idx = rtrim($uri, '/') . '/index.php';
    if (file_exists(__DIR__ . $idx)) {
        $_SERVER['SCRIPT_NAME'] = $idx;
        require __DIR__ . $idx;
        return true;
    }
}

// Default to index.php at root
require __DIR__ . '/index.php';
