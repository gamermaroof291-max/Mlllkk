<?php
require_once __DIR__ . '/common/config.php';
require_login();

$catId = (int)($_GET['cat_id'] ?? 0);
$prodId = (int)($_GET['product_id'] ?? 0);
$playerUid = sanitize($_GET['player_uid'] ?? '');
$zoneId = sanitize($_GET['zone_id'] ?? '');
$opt = ($_GET['opt'] ?? 'manual') === 'wallet' ? 'wallet' : 'manual';

$stmt = db()->prepare("SELECT * FROM categories WHERE id = ? AND status='active'");
$stmt->execute([$catId]); $g = $stmt->fetch();

$stmt = db()->prepare("SELECT * FROM products WHERE id = ? AND cat_id = ? AND status='active'");
$stmt->execute([$prodId, $catId]); $p = $stmt->fetch();

if (!$g || !$p) { header('Location: ' . site_url('index.php')); exit; }

$me  = current_user();
$pms = db()->query("SELECT * FROM payment_methods WHERE status='active' ORDER BY sort_order ASC")->fetchAll();
$pageTitle = 'Pay — ' . $p['name'];
require __DIR__ . '/common/header.php';
?>
<div class="card p-4 mb-4">
  <div class="text-xs uppercase font-bold text-muted mb-2">Order Summary</div>
  <div class="flex items-center gap-3">
    <img src="<?= e($g['image']) ?>" class="w-14 h-14 rounded-lg object-cover" alt="">
    <div class="flex-1 min-w-0">
      <div class="font-bold text-sm text-ink truncate"><?= e($g['name']) ?></div>
      <div class="text-xs text-muted truncate"><?= e($p['name']) ?></div>
      <?php if ($playerUid): ?>
        <div class="text-[11px] text-muted mt-0.5">UID: <span class="font-mono text-ink font-semibold"><?= e($playerUid) ?></span><?= $zoneId ? ' • Zone <span class="font-mono">'.e($zoneId).'</span>' : '' ?></div>
      <?php endif; ?>
    </div>
    <div class="text-right">
      <div class="text-[10px] uppercase font-bold text-muted">Total</div>
      <div class="text-brand font-extrabold text-lg"><?= format_money($p['price']) ?></div>
    </div>
  </div>
</div>

<?php if ($opt === 'wallet'): ?>
  <div class="card p-5 mb-4">
    <h3 class="font-extrabold text-ink mb-2"><i class="fa-solid fa-wallet text-brand mr-1"></i>Wallet Pay</h3>
    <?php if ((float)$me['balance'] >= (float)$p['price']): ?>
      <p class="text-sm text-muted mb-3">Wallet balance: <b class="text-brand"><?= format_money($me['balance']) ?></b>. <?= format_money($p['price']) ?> will be deducted instantly.</p>
      <button id="walletPay" class="btn-blue"><i class="fa-solid fa-bolt"></i>Pay <?= format_money($p['price']) ?> Now</button>
    <?php else: ?>
      <p class="text-sm text-[#DC2626] mb-3"><i class="fa-solid fa-circle-exclamation mr-1"></i>Insufficient balance. You need <b><?= format_money($p['price'] - $me['balance']) ?></b> more.</p>
      <a href="<?= e(site_url('addmoney.php')) ?>" class="btn-blue"><i class="fa-solid fa-plus"></i>Add Money</a>
    <?php endif; ?>
  </div>
<?php else: ?>
  <div class="card p-4 mb-3">
    <div class="text-[13px] font-bold text-ink mb-3">Choose payment method</div>
    <div class="grid grid-cols-3 gap-2">
      <?php foreach ($pms as $pm): ?>
        <button type="button" class="pm-card border-2 border-[#E5ECF5] rounded-xl p-2 text-center bg-white transition" data-id="<?= (int)$pm['id'] ?>" data-name="<?= e($pm['name']) ?>" data-number="<?= e($pm['number']) ?>" data-desc="<?= e($pm['description']) ?>" data-qr="<?= e($pm['qr_image']) ?>">
          <img src="<?= e($pm['logo'] ?: 'https://placehold.co/100x40?text='.urlencode($pm['name'])) ?>" class="w-full h-9 object-contain rounded mb-1">
          <div class="text-[11px] font-semibold text-ink"><?= e($pm['name']) ?></div>
        </button>
      <?php endforeach; ?>
    </div>
  </div>

  <div id="pmDetails" class="card p-4 mb-3 hidden">
    <div id="pmName" class="font-bold text-ink mb-2"></div>
    <div class="grid grid-cols-3 gap-3 items-center">
      <img id="pmQr" src="" class="w-full rounded-lg bg-[#F0F4FA] col-span-1">
      <div class="col-span-2 text-sm">
        <div class="text-xs uppercase font-bold text-muted">Send money to</div>
        <div id="pmNumber" class="font-extrabold text-lg text-brand tracking-wide select-all"></div>
        <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('pmNumber').textContent); window.czToast('Number copied','success');" class="text-xs text-brand mt-1"><i class="fa-solid fa-copy"></i> Copy number</button>
        <div id="pmDesc" class="text-[11px] text-muted mt-2"></div>
      </div>
    </div>
  </div>

  <div class="card p-4 mb-4">
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs font-semibold uppercase text-muted">Your Number</label>
        <input id="senderNumber" class="input mt-1" placeholder="Sender mobile number">
      </div>
      <div>
        <label class="text-xs font-semibold uppercase text-muted">Transaction ID</label>
        <input id="trxId" class="input mt-1" placeholder="TxnID from SMS">
      </div>
    </div>
    <button id="manualPay" class="btn-blue mt-3"><i class="fa-solid fa-paper-plane"></i>Submit Order</button>
  </div>
<?php endif; ?>

<a href="<?= e(site_url('game_detail.php?id='.$catId)) ?>" class="block text-center text-sm text-muted mt-4"><i class="fa-solid fa-arrow-left mr-1"></i>Back</a>

<style>.pm-card.selected { border-color: var(--c-orange) !important; background:#FFF5EE; }</style>
<script>
var ROOT='<?= e(site_url('')) ?>';
var orderData={ cat_id:<?= (int)$catId ?>, product_id:<?= (int)$prodId ?>,
  player_uid:<?= json_encode($playerUid) ?>, zone_id:<?= json_encode($zoneId) ?>, amount:<?= (float)$p['price'] ?> };
var selectedPm=null;

document.querySelectorAll('.pm-card').forEach(function(c){
  c.addEventListener('click', function(){
    document.querySelectorAll('.pm-card').forEach(x=>x.classList.remove('selected'));
    c.classList.add('selected'); selectedPm=c.dataset.id;
    document.getElementById('pmName').innerHTML='<i class="fa-solid fa-circle-info text-brand mr-1"></i>'+c.dataset.name+' Instructions';
    document.getElementById('pmNumber').textContent=c.dataset.number;
    document.getElementById('pmDesc').textContent=c.dataset.desc||'';
    document.getElementById('pmQr').src=c.dataset.qr || ('https://placehold.co/200x200?text='+encodeURIComponent(c.dataset.name));
    document.getElementById('pmDetails').classList.remove('hidden');
  });
});

async function postJson(url, data){
  var r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF':'<?= e(csrf_token()) ?>'},body:JSON.stringify(data)});
  return await r.json();
}

var walletBtn=document.getElementById('walletPay');
if (walletBtn) walletBtn.addEventListener('click', async function(){
  walletBtn.disabled=true; walletBtn.innerHTML='<div class="dot-loader"><span></span><span></span><span></span></div>';
  var res=await postJson(ROOT+'api/order_create.php', Object.assign({payment_method:'wallet', _csrf:'<?= e(csrf_token()) ?>'}, orderData));
  if (res.success) { window.czToast('Order placed!','success'); setTimeout(()=>location.href=ROOT+'order.php',600); }
  else { window.czToast(res.message||'Failed','error'); walletBtn.disabled=false; walletBtn.innerHTML='<i class="fa-solid fa-bolt"></i>Pay Now'; }
});

var manualBtn=document.getElementById('manualPay');
if (manualBtn) manualBtn.addEventListener('click', async function(){
  if (!selectedPm) { window.czToast('Select a payment method','warn'); return; }
  var sn=document.getElementById('senderNumber').value.trim();
  var tx=document.getElementById('trxId').value.trim();
  if (!sn || !tx) { window.czToast('Enter sender number & TxnID','warn'); return; }
  this.disabled=true; this.innerHTML='<div class="dot-loader"><span></span><span></span><span></span></div>';
  var res=await postJson(ROOT+'api/order_create.php', Object.assign({
    payment_method:'manual', payment_method_id:selectedPm, sender_number:sn, trx_id:tx, _csrf:'<?= e(csrf_token()) ?>'
  }, orderData));
  if (res.success) { window.czToast('Order submitted!','success'); setTimeout(()=>location.href=ROOT+'order.php',700); }
  else { window.czToast(res.message||'Failed','error'); this.disabled=false; this.innerHTML='<i class="fa-solid fa-paper-plane"></i>Submit Order'; }
});
</script>
<?php require __DIR__ . '/common/footer.php'; ?>
