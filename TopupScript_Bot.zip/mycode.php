<?php
require_once __DIR__ . '/common/config.php';
require_login();
$me = current_user();

$msg = ''; $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) $err = 'Session expired.';
    else {
        $code = strtoupper(trim((string)($_POST['code'] ?? '')));
        if (!$code) { $err = 'Enter a code'; }
        else {
            // Promo redeem stub — extend later
            $err = 'Invalid code.';
        }
    }
}

$stmt = db()->prepare("SELECT oc.code, oc.assigned_at, c.name AS game_name, p.name AS product_name
  FROM order_codes oc
  JOIN orders o ON o.id = oc.order_id
  JOIN categories c ON c.id = o.cat_id
  JOIN products p ON p.id = o.product_id
  WHERE o.user_id = ? ORDER BY oc.id DESC");
$stmt->execute([$me['id']]);
$codes = $stmt->fetchAll();

$pageTitle = 'My Codes — ' . setting('site_name');
require __DIR__ . '/common/header.php';
?>

<div class="card mb-4">
  <div class="flex items-center justify-between p-4 border-b border-[#E5ECF5]">
    <h1 class="font-extrabold text-[16px] text-ink flex items-center gap-2"><i class="fa-solid fa-list text-brand"></i>My Codes</h1>
    <button onclick="document.getElementById('redeemBox').classList.toggle('hidden')" class="bg-brand text-white text-xs font-bold px-4 py-2 rounded-md">Reedeem Code</button>
  </div>

  <div id="redeemBox" class="<?= ($err||$msg)?'':'hidden' ?> p-4 border-b border-[#E5ECF5]">
    <?php if ($msg): ?><div class="bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-lg p-2 mb-2 text-sm"><?= e($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="bg-rose-50 border border-rose-200 text-rose-700 rounded-lg p-2 mb-2 text-sm"><?= e($err) ?></div><?php endif; ?>
    <form method="post" class="flex gap-2">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <input name="code" class="input flex-1" placeholder="Enter promo / gift code" required>
      <button class="bg-brand text-white px-4 rounded-lg font-bold text-sm">Apply</button>
    </form>
  </div>
</div>

<?php if (!$codes): ?>
  <!-- empty state intentionally blank like screenshot -->
<?php else: ?>
<div class="space-y-3">
  <?php foreach ($codes as $c): ?>
  <div class="card p-3">
    <div class="text-[11px] text-muted uppercase font-bold mb-1"><?= e($c['game_name']) ?> • <?= e($c['product_name']) ?></div>
    <div class="flex items-center justify-between gap-2 bg-[#F0F4FA] rounded-lg px-3 py-2">
      <span class="font-mono font-bold text-ink truncate"><?= e($c['code']) ?></span>
      <button onclick="navigator.clipboard.writeText('<?= e($c['code']) ?>'); window.czToast('Copied','success');" class="text-brand"><i class="fa-solid fa-copy"></i></button>
    </div>
    <div class="text-[10px] text-muted mt-1"><?= time_ago($c['assigned_at']) ?></div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/common/footer.php'; ?>
