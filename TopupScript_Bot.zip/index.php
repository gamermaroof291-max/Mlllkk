<?php
require_once __DIR__ . '/common/config.php';

if (!file_exists(__DIR__ . '/data/install.lock')) {
    header('Location: ' . site_url('install.php')); exit;
}

$pageTitle = setting('site_title', 'Code Zen Topup');
$sliders   = db()->query("SELECT * FROM sliders WHERE status='active' ORDER BY sort_order ASC, id ASC")->fetchAll();
$games     = db()->query("SELECT * FROM categories WHERE status='active' ORDER BY sort_order ASC, id ASC")->fetchAll();

$grouped = [];
foreach ($games as $g) { $sec = $g['section'] ?: 'Games'; $grouped[$sec][] = $g; }

$activeApp = null;
try {
    $stmt = db()->query("SELECT * FROM app_versions WHERE status='active' ORDER BY id DESC LIMIT 1");
    $activeApp = $stmt->fetch() ?: null;
} catch(Throwable $e) {}

require __DIR__ . '/common/header.php';
?>

<?php if ($sliders): ?>
<section class="mb-5">
  <div class="relative overflow-hidden rounded-2xl card">
    <div id="sliderTrack" class="flex transition-transform duration-700 ease-out">
      <?php foreach ($sliders as $s): ?>
        <a href="<?= e($s['link'] ?: '#') ?>" class="min-w-full block">
          <img src="<?= e($s['image']) ?>" alt="" class="w-full h-44 sm:h-52 object-cover">
        </a>
      <?php endforeach; ?>
    </div>
    <?php if (count($sliders) > 1): ?>
    <div class="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5">
      <?php foreach ($sliders as $i => $s): ?>
        <button data-dot="<?= $i ?>" class="w-2 h-2 rounded-full bg-white/70 transition slider-dot"></button>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>
<script>
(function(){
  var idx=0,total=<?= count($sliders) ?>;
  var track=document.getElementById('sliderTrack');
  var dots=document.querySelectorAll('.slider-dot');
  function go(i){ idx=(i+total)%total; track.style.transform='translateX(-'+(idx*100)+'%)';
    dots.forEach((d,j)=>{ d.classList.toggle('bg-white', j===idx); d.classList.toggle('w-6', j===idx); }); }
  go(0); dots.forEach((d,j)=>d.onclick=()=>go(j));
  if (total > 1) setInterval(()=>go(idx+1), 5000);
})();
</script>
<?php endif; ?>

<?php if ($activeApp && setting('app_show','1') === '1'): ?>
<a href="<?= e(site_url('app.php')) ?>" class="block mb-5 card overflow-hidden">
  <div class="relative p-4 bg-gradient-to-r from-[#0F1E3D] via-[#1A8FBD] to-[#0F1E3D] text-white">
    <div class="flex items-center gap-3">
      <div class="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur flex items-center justify-center text-2xl"><i class="fa-brands fa-android"></i></div>
      <div class="flex-1 min-w-0">
        <div class="text-[10px] uppercase tracking-widest text-white/70 font-bold">Official App</div>
        <div class="font-extrabold text-base truncate"><?= e(setting('app_name','Download our App')) ?></div>
        <div class="text-xs text-white/80">Faster checkout • Push offers • v<?= e($activeApp['version']) ?></div>
      </div>
      <div class="bg-white text-navy text-xs font-extrabold px-3 py-2 rounded-lg flex items-center gap-1"><i class="fa-solid fa-download"></i>Get</div>
    </div>
  </div>
</a>
<?php endif; ?>

<?php foreach ($grouped as $section => $list): ?>
  <section class="mb-7">
    <div class="sec-cap mb-4"><?= e(strtoupper($section)) ?></div>
    <div class="grid grid-cols-3 gap-3">
      <?php foreach ($list as $g): ?>
        <a href="<?= e(site_url('game_detail.php?id=' . $g['id'])) ?>" class="block group">
          <div class="card overflow-hidden">
            <div class="aspect-square bg-[#F0F4FA] overflow-hidden">
              <img src="<?= e($g['image'] ?: 'https://placehold.co/300x300/1A8FBD/fff?text=Game') ?>" alt="<?= e($g['name']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
            </div>
          </div>
          <div class="text-center mt-2 text-[12.5px] font-semibold text-ink leading-tight px-1"><?= e($g['name']) ?></div>
        </a>
      <?php endforeach; ?>
    </div>
  </section>
<?php endforeach; ?>

<?php if (setting('home_warning_text')): ?>
<div class="card overflow-hidden mb-6">
  <div class="bg-[#FEF3C7] border-b-2 border-dashed border-[#F59E0B] px-4 py-2 text-center">
    <span class="inline-flex items-center gap-1.5 text-[#B45309] font-extrabold text-sm">
      <i class="fa-solid fa-triangle-exclamation"></i><?= e(setting('home_warning_title','সতর্কবার্তা')) ?>
    </span>
  </div>
  <div class="p-4 text-[13px] text-ink leading-relaxed text-center"><?= nl2br(e(setting('home_warning_text'))) ?></div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/common/footer.php'; ?>
