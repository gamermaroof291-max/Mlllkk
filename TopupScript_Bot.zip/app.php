<?php
require_once __DIR__ . '/common/config.php';

try {
    $stmt = db()->query("SELECT * FROM app_versions WHERE status='active' ORDER BY id DESC LIMIT 1");
    $latest = $stmt->fetch() ?: null;
    $history = db()->query("SELECT * FROM app_versions WHERE status='active' ORDER BY id DESC LIMIT 10")->fetchAll();
} catch (Throwable $e) { $latest = null; $history = []; }

$pageTitle = 'App Download — ' . setting('site_name');
require __DIR__ . '/common/header.php';
$siteName = setting('site_name','Code Zen Topup');
$sym = setting('currency_symbol','৳');
$features = array_filter(array_map('trim', explode("\n", (string)setting('app_features'))));
?>

<div class="card overflow-hidden mb-5">
  <div class="relative p-5 text-white text-center" style="background:linear-gradient(135deg,#0F1E3D 0%, #1A8FBD 60%, #0F1E3D 100%);">
    <div class="w-20 h-20 rounded-3xl bg-white/15 backdrop-blur flex items-center justify-center mx-auto mb-3 text-4xl shadow-2xl">
      <?php if (setting('logo_image')): ?>
        <img src="<?= e(site_url(setting('logo_image'))) ?>" class="w-12 h-12 object-contain">
      <?php else: ?>
        <i class="fa-brands fa-android"></i>
      <?php endif; ?>
    </div>
    <h1 class="text-xl font-extrabold mb-1"><?= e(setting('app_name', $siteName.' App')) ?></h1>
    <p class="text-white/80 text-sm"><?= e(setting('app_subtitle','Official Android App')) ?></p>
    <?php if ($latest): ?>
      <div class="mt-3 inline-flex items-center gap-2 text-xs bg-white/15 px-3 py-1 rounded-full">
        <span class="font-bold">v<?= e($latest['version']) ?></span>
        <span class="opacity-60">•</span>
        <span><?= number_format(($latest['file_size'] ?: 0)/1048576, 1) ?> MB</span>
        <?php if ((int)$latest['downloads'] > 0): ?>
          <span class="opacity-60">•</span>
          <span><?= number_format((int)$latest['downloads']) ?> downloads</span>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="p-5">
    <?php if ($latest): ?>
      <a href="<?= e(site_url('app_download.php?id='.$latest['id'])) ?>" class="btn-blue text-base">
        <i class="fa-solid fa-download text-lg"></i>Download APK (v<?= e($latest['version']) ?>)
      </a>
      <p class="text-[11px] text-muted text-center mt-3">
        <i class="fa-solid fa-shield-halved mr-1"></i>Safe direct download. After download, allow "Install from unknown sources" in your phone settings.
      </p>
    <?php else: ?>
      <div class="text-center py-4">
        <i class="fa-solid fa-clock text-4xl text-muted mb-3"></i>
        <h3 class="font-bold text-ink mb-1">App coming soon</h3>
        <p class="text-sm text-muted">Our official Android app is being prepared. Stay tuned!</p>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php if ($features): ?>
<div class="card p-5 mb-5">
  <h3 class="font-extrabold text-ink mb-3 text-[15px]">App Features</h3>
  <ul class="space-y-2.5">
    <?php foreach ($features as $f): ?>
      <li class="flex items-start gap-3">
        <span class="w-7 h-7 rounded-full bg-brandSoft text-brand flex items-center justify-center flex-shrink-0"><i class="fa-solid fa-check text-xs"></i></span>
        <span class="text-sm text-ink leading-snug"><?= e($f) ?></span>
      </li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<div class="card p-5 mb-5">
  <h3 class="font-extrabold text-ink mb-3 text-[15px]"><i class="fa-solid fa-circle-info text-brand mr-1"></i>How to Install</h3>
  <ol class="space-y-3 text-sm text-ink">
    <li class="flex gap-3"><span class="step-num flex-shrink-0">1</span><span>Tap the <b>Download APK</b> button above and wait for the file to download.</span></li>
    <li class="flex gap-3"><span class="step-num flex-shrink-0">2</span><span>Open <b>Settings → Security</b> and enable <b>"Install from unknown sources"</b> for your browser.</span></li>
    <li class="flex gap-3"><span class="step-num flex-shrink-0">3</span><span>Open the downloaded APK file and tap <b>Install</b>.</span></li>
    <li class="flex gap-3"><span class="step-num flex-shrink-0">4</span><span>Launch the app and login with your existing account.</span></li>
  </ol>
</div>

<?php if (count($history) > 1): ?>
<div class="card p-5">
  <h3 class="font-extrabold text-ink mb-3 text-[15px]">Version History</h3>
  <div class="space-y-3">
    <?php foreach ($history as $v): ?>
      <div class="flex items-start justify-between gap-3 pb-3 border-b border-[#E5ECF5] last:border-0 last:pb-0">
        <div class="min-w-0">
          <div class="font-bold text-ink text-sm">v<?= e($v['version']) ?>
            <?php if ($v['id'] === $latest['id']): ?><span class="pill bg-emerald-500 text-white ml-1">Latest</span><?php endif; ?>
          </div>
          <?php if ($v['changelog']): ?><div class="text-xs text-muted mt-1 whitespace-pre-line"><?= e($v['changelog']) ?></div><?php endif; ?>
          <div class="text-[10px] text-muted mt-1"><?= time_ago($v['created_at']) ?> • <?= number_format(($v['file_size'] ?: 0)/1048576,1) ?> MB</div>
        </div>
        <a href="<?= e(site_url('app_download.php?id='.$v['id'])) ?>" class="text-brand text-xs font-bold whitespace-nowrap">Download</a>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/common/footer.php'; ?>
