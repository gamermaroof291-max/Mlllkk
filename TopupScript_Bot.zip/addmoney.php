<?php
require_once __DIR__ . '/common/config.php';
require_login();
$me = current_user();
$pms = db()->query("SELECT * FROM payment_methods WHERE status='active' ORDER BY sort_order ASC")->fetchAll();
$min = (float)setting('min_addmoney','20');
$max = (float)setting('max_addmoney','50000');
$video = setting('addmoney_video','');
$pageTitle = 'Add Money — ' . setting('site_name');
require __DIR__ . '/common/header.php';
?>

<div class="card p-4 mb-4">
  <h2 class="font-extrabold text-[16px] text-ink mb-3 flex items-center gap-2">
    <i class="fa-solid fa-wallet text-brand"></i>Add Money
  </h2>
  <label class="block text-[13px] font-bold text-ink mb-1.5">Enter the amount</label>
  <input id="amt" class="input" inputmode="numeric" placeholder="Amount" min="<?= $min ?>" max="<?= $max ?>">
  <div class="text-[11px] text-muted mt-1">Min <?= e(setting('currency_symbol','৳')) ?><?= number_format($min,0) ?> • Max <?= e(setting('currency_symbol','৳')) ?><?= number_format($max,0) ?></div>

  <div class="grid grid-cols-4 gap-2 mt-3">
    <?php foreach ([100,200,500,1000] as $v): ?>
      <button type="button" onclick="document.getElementById('amt').value=<?= $v ?>" class="text-[12px] font-bold text-brand bg-brandSoft border border-[#C7E2EE] rounded-lg py-1.5"><?= e(setting('currency_symbol','৳')) ?><?= $v ?></button>
    <?php endforeach; ?>
  </div>
  <button id="proceed" class="btn-blue mt-4">Click Here To Add Money</button>
</div>

<?php if ($video): ?>
<div class="card p-4 mb-4">
  <h3 class="font-extrabold text-[15px] text-ink mb-3 flex items-center gap-2">
    <i class="fa-solid fa-display text-brand"></i>How to add money
  </h3>
  <div class="rounded-xl overflow-hidden bg-black aspect-video">
    <iframe src="<?= e($video) ?>" class="w-full h-full" frameborder="0" allowfullscreen></iframe>
  </div>
  <?php if (setting('addmoney_note')): ?>
    <p class="text-[12px] text-muted mt-3"><?= e(setting('addmoney_note')) ?></p>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Method picker (initially hidden) -->
<div id="methodPicker" class="card p-4 mb-4 hidden">
  <h3 class="font-extrabold text-[15px] text-ink mb-3">Choose payment method</h3>
  <div class="grid grid-cols-3 gap-2">
    <?php foreach ($pms as $pm): ?>
      <button type="button" class="pm-card border-2 border-[#E5ECF5] rounded-xl p-2 text-center bg-white" data-id="<?= (int)$pm['id'] ?>" data-name="<?= e($pm['name']) ?>" data-number="<?= e($pm['number']) ?>" data-desc="<?= e($pm['description']) ?>" data-qr="<?= e($pm['qr_image']) ?>">
        <img src="<?= e($pm['logo']) ?>" class="w-full h-9 object-contain rounded mb-1">
        <div class="text-[11px] font-semibold text-ink"><?= e($pm['name']) ?></div>
      </button>
    <?php endforeach; ?>
  </div>
</div>

<div id="pmDetails" class="card p-4 mb-4 hidden">
  <div id="pmName" class="font-bold text-ink mb-2"></div>
  <div class="grid grid-cols-3 gap-3 items-center">
    <img id="pmQr" src="" class="w-full rounded-lg bg-[#F0F4FA] col-span-1">
    <div class="col-span-2 text-sm">
      <div class="text-xs uppercase font-bold text-muted">Send money to</div>
      <div id="pmNumber" class="font-extrabold text-lg text-brand tracking-wide select-all"></div>
      <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('pmNumber').textContent); window.czToast('Number copied','success');" class="text-xs text-brand mt-1"><i class="fa-solid fa-copy"></i> Copy</button>
      <div id="pmDesc" class="text-[11px] text-muted mt-2"></div>
    </div>
  </div>
  <div class="grid grid-cols-2 gap-3 mt-3">
    <div><label class="text-xs font-semibold uppercase text-muted">Your Number</label><input id="senderNumber" class="input mt-1"></div>
    <div><label class="text-xs font-semibold uppercase text-muted">Transaction ID</label><input id="trxId" class="input mt-1"></div>
  </div>
  <button id="topupSubmit" class="btn-blue mt-3"><i class="fa-solid fa-paper-plane"></i>Submit Top-up Request</button>
</div>

<style>.pm-card.selected { border-color:var(--c-orange) !important; background:#FFF5EE; }</style>
<script>
var ROOT='<?= e(site_url('')) ?>';
var amount=0, selectedPm=null;
document.getElementById('proceed').addEventListener('click', function(){
  var v=parseFloat(document.getElementById('amt').value||'0');
  if (!v || v<<?= $min ?> || v><?= $max ?>) { window.czToast('Enter valid amount','warn'); return; }
  amount=v;
  document.getElementById('methodPicker').classList.remove('hidden');
  document.getElementById('methodPicker').scrollIntoView({behavior:'smooth'});
});
document.querySelectorAll('.pm-card').forEach(function(c){
  c.addEventListener('click', function(){
    document.querySelectorAll('.pm-card').forEach(x=>x.classList.remove('selected'));
    c.classList.add('selected'); selectedPm=c.dataset.id;
    document.getElementById('pmName').innerHTML='<i class="fa-solid fa-circle-info text-brand mr-1"></i>'+c.dataset.name+' Instructions';
    document.getElementById('pmNumber').textContent=c.dataset.number;
    document.getElementById('pmDesc').textContent=c.dataset.desc||'';
    document.getElementById('pmQr').src=c.dataset.qr || ('https://placehold.co/200x200?text='+encodeURIComponent(c.dataset.name));
    document.getElementById('pmDetails').classList.remove('hidden');
    document.getElementById('pmDetails').scrollIntoView({behavior:'smooth'});
  });
});
document.getElementById('topupSubmit').addEventListener('click', async function(){
  if (!amount || !selectedPm) { window.czToast('Fill all required fields','warn'); return; }
  var sn=document.getElementById('senderNumber').value.trim();
  var tx=document.getElementById('trxId').value.trim();
  if (!sn || !tx) { window.czToast('Enter sender number & TxnID','warn'); return; }
  this.disabled=true; this.innerHTML='<div class="dot-loader"><span></span><span></span><span></span></div>';
  var r=await fetch(ROOT+'api/topup_create.php',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({amount:amount, method_id:selectedPm, sender_number:sn, trx_id:tx, _csrf:'<?= e(csrf_token()) ?>'})});
  var res=await r.json();
  if (res.success) { window.czToast('Top-up request submitted!','success'); setTimeout(()=>location.href=ROOT+'profile.php',700); }
  else { window.czToast(res.message||'Failed','error'); this.disabled=false; this.innerHTML='<i class="fa-solid fa-paper-plane"></i>Submit'; }
});
</script>
<?php require __DIR__ . '/common/footer.php'; ?>
