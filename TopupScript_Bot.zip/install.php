<?php
require_once __DIR__ . '/common/config.php';

$lockFile   = __DIR__ . '/data/install.lock';
$forceReset = isset($_GET['reset']) && $_GET['reset'] === '1';
$messages   = [];
$errors     = [];

try {
    $pdo     = db();
    $isMysql = db_driver() === 'mysql';

    // ----------------------- TABLE DEFINITIONS -----------------------
    $tables = [
        'users' => $isMysql
            ? "CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, phone VARCHAR(40) UNIQUE,
                email VARCHAR(160) UNIQUE, password VARCHAR(255) NOT NULL, balance DECIMAL(12,2) NOT NULL DEFAULT 0,
                avatar VARCHAR(255), status VARCHAR(20) NOT NULL DEFAULT 'active', support_pin VARCHAR(10) NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT UNIQUE,
                email TEXT UNIQUE, password TEXT NOT NULL, balance REAL NOT NULL DEFAULT 0, avatar TEXT,
                status TEXT NOT NULL DEFAULT 'active', support_pin TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'admin' => $isMysql
            ? "CREATE TABLE admin (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL, last_login DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE admin (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL, last_login TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'categories' => $isMysql
            ? "CREATE TABLE categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(160) NOT NULL,
                section VARCHAR(80) NOT NULL DEFAULT 'Featured', type VARCHAR(20) NOT NULL DEFAULT 'uid',
                description TEXT, rules TEXT, image VARCHAR(255), zone_required TINYINT NOT NULL DEFAULT 0,
                status VARCHAR(20) NOT NULL DEFAULT 'active', sort_order INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
                section TEXT NOT NULL DEFAULT 'Featured', type TEXT NOT NULL DEFAULT 'uid',
                description TEXT, rules TEXT, image TEXT, zone_required INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'active', sort_order INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'products' => $isMysql
            ? "CREATE TABLE products (id INT AUTO_INCREMENT PRIMARY KEY, cat_id INT NOT NULL, name VARCHAR(160) NOT NULL,
                price DECIMAL(12,2) NOT NULL, stock INT NOT NULL DEFAULT -1, sort_order INT NOT NULL DEFAULT 0,
                featured TINYINT NOT NULL DEFAULT 0, status VARCHAR(20) NOT NULL DEFAULT 'active',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, cat_id INTEGER NOT NULL, name TEXT NOT NULL,
                price REAL NOT NULL, stock INTEGER NOT NULL DEFAULT -1, sort_order INTEGER NOT NULL DEFAULT 0,
                featured INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'active',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'sliders' => $isMysql
            ? "CREATE TABLE sliders (id INT AUTO_INCREMENT PRIMARY KEY, image VARCHAR(255) NOT NULL,
                link VARCHAR(255), sort_order INT NOT NULL DEFAULT 0,
                status VARCHAR(20) NOT NULL DEFAULT 'active',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE sliders (id INTEGER PRIMARY KEY AUTOINCREMENT, image TEXT NOT NULL, link TEXT,
                sort_order INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'active',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'settings' => $isMysql
            ? "CREATE TABLE settings (id INT AUTO_INCREMENT PRIMARY KEY, key_name VARCHAR(120) UNIQUE NOT NULL,
                value LONGTEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE settings (id INTEGER PRIMARY KEY AUTOINCREMENT, key_name TEXT UNIQUE NOT NULL, value TEXT)",

        'payment_methods' => $isMysql
            ? "CREATE TABLE payment_methods (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL,
                logo VARCHAR(255), qr_image VARCHAR(255), number VARCHAR(120), description TEXT,
                status VARCHAR(20) NOT NULL DEFAULT 'active', sort_order INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE payment_methods (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
                logo TEXT, qr_image TEXT, number TEXT, description TEXT, status TEXT NOT NULL DEFAULT 'active',
                sort_order INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'wallet_topup' => $isMysql
            ? "CREATE TABLE wallet_topup (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
                amount DECIMAL(12,2) NOT NULL, method_id INT, sender_number VARCHAR(120), trx_id VARCHAR(120),
                status VARCHAR(20) NOT NULL DEFAULT 'pending', note TEXT,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE wallet_topup (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
                amount REAL NOT NULL, method_id INTEGER, sender_number TEXT, trx_id TEXT,
                status TEXT NOT NULL DEFAULT 'pending', note TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'transactions' => $isMysql
            ? "CREATE TABLE transactions (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
                type VARCHAR(20) NOT NULL, amount DECIMAL(12,2) NOT NULL, note TEXT, ref_id VARCHAR(120),
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
                type TEXT NOT NULL, amount REAL NOT NULL, note TEXT, ref_id TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'orders' => $isMysql
            ? "CREATE TABLE orders (id INT AUTO_INCREMENT PRIMARY KEY, order_code VARCHAR(40) UNIQUE NOT NULL,
                user_id INT NOT NULL, cat_id INT NOT NULL, product_id INT NOT NULL, quantity INT NOT NULL DEFAULT 1,
                total_amount DECIMAL(12,2) NOT NULL, player_uid VARCHAR(120), zone_id VARCHAR(40),
                payment_method VARCHAR(20) NOT NULL, payment_method_id INT, trx_id VARCHAR(120),
                sender_number VARCHAR(120), status VARCHAR(20) NOT NULL DEFAULT 'pending', admin_note TEXT,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE orders (id INTEGER PRIMARY KEY AUTOINCREMENT, order_code TEXT UNIQUE NOT NULL,
                user_id INTEGER NOT NULL, cat_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL DEFAULT 1, total_amount REAL NOT NULL, player_uid TEXT, zone_id TEXT,
                payment_method TEXT NOT NULL, payment_method_id INTEGER, trx_id TEXT, sender_number TEXT,
                status TEXT NOT NULL DEFAULT 'pending', admin_note TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'redeem_codes' => $isMysql
            ? "CREATE TABLE redeem_codes (id INT AUTO_INCREMENT PRIMARY KEY, cat_id INT NOT NULL,
                product_id INT NOT NULL, code VARCHAR(255) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'unused',
                assigned_order_id INT, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                used_at DATETIME NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE redeem_codes (id INTEGER PRIMARY KEY AUTOINCREMENT, cat_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL, code TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'unused',
                assigned_order_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, used_at TEXT)",

        'order_codes' => $isMysql
            ? "CREATE TABLE order_codes (id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL,
                code_id INT NOT NULL, code VARCHAR(255) NOT NULL,
                assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE order_codes (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL,
                code_id INTEGER NOT NULL, code TEXT NOT NULL,
                assigned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        // ------- NEW TABLES -------
        'helplines' => $isMysql
            ? "CREATE TABLE helplines (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(160) NOT NULL,
                subtitle VARCHAR(255), icon VARCHAR(60), link VARCHAR(255),
                status VARCHAR(20) NOT NULL DEFAULT 'active', sort_order INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE helplines (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
                subtitle TEXT, icon TEXT, link TEXT, status TEXT NOT NULL DEFAULT 'active',
                sort_order INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",

        'app_versions' => $isMysql
            ? "CREATE TABLE app_versions (id INT AUTO_INCREMENT PRIMARY KEY, version VARCHAR(40) NOT NULL,
                file_path VARCHAR(255) NOT NULL, file_size INT NOT NULL DEFAULT 0, changelog TEXT,
                downloads INT NOT NULL DEFAULT 0, status VARCHAR(20) NOT NULL DEFAULT 'active',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            : "CREATE TABLE app_versions (id INTEGER PRIMARY KEY AUTOINCREMENT, version TEXT NOT NULL,
                file_path TEXT NOT NULL, file_size INTEGER NOT NULL DEFAULT 0, changelog TEXT,
                downloads INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'active',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)",
    ];

    // ----------------------- DROP if reset -----------------------
    if ($forceReset) {
        foreach (array_reverse(array_keys($tables)) as $t) { $pdo->exec("DROP TABLE IF EXISTS $t"); }
        @unlink($lockFile);
        $messages[] = "All existing tables dropped (reset).";
    }

    // ----------------------- CREATE missing tables -----------------------
    $created = 0; $skipped = 0;
    foreach ($tables as $name => $sql) {
        $exists = false;
        try { $pdo->query("SELECT 1 FROM $name LIMIT 1"); $exists = true; } catch (Throwable $e) { $exists = false; }
        if ($exists) { $skipped++; }
        else { $pdo->exec($sql); $created++; $messages[] = "Created table <code>$name</code>."; }
    }
    if ($skipped) $messages[] = "$skipped existing tables left untouched.";

    $alreadyInstalled = file_exists($lockFile) && !$forceReset;

    // ----------------------- ADD MISSING SETTINGS -----------------------
    $defaults = [
        'site_name'         => 'Code Zen Topup',
        'site_title'        => 'Code Zen Topup — Premium Game Recharges',
        'site_description'  => 'Top up your favorite games instantly with bKash, Nagad, Rocket and more.',
        'logo_text'         => 'Code Zen',
        'logo_tag'          => 'TOPUP',
        'logo_image'        => '',
        'currency_name'     => 'Bangladeshi Taka',
        'currency_symbol'   => '৳',
        'currency_code'     => 'BDT',
        'min_addmoney'      => '20',
        'max_addmoney'      => '50000',
        'marquee_text'      => '🔥 Welcome to Code Zen Topup — instant game recharges, 24/7 support! 🎮',
        'marquee_enabled'   => '1',
        'fab_link'          => 'https://wa.me/8801642667711',
        'fab_icon'          => 'fa-phone',
        'fab_label'         => 'সাহায্য লাগবে ?',
        'fab_label_show'    => '1',
        'whatsapp_url'      => 'https://wa.me/8801642667711',
        'telegram_url'      => 'https://t.me/codezen',
        'facebook_url'      => 'https://facebook.com/codezen',
        'youtube_url'       => 'https://youtube.com',
        'instagram_url'     => 'https://instagram.com/codezen',
        'support_phone'     => '01642667711',
        'support_email'     => 'support@codezen.app',
        'addmoney_video'    => 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        'addmoney_note'     => 'অ্যাকাউন্টে টাকা অ্যাড করতে নিচের ভিডিওটি দেখুন। যেকোনো সমস্যায় হোয়াটসঅ্যাপে যোগাযোগ করুন।',
        'primary_color'     => '#1A8FBD',
        'accent_color'      => '#F97316',
        'gold_color'        => '#F59E0B',
        'navy_color'        => '#0F1E3D',
        'theme_default'     => 'light',
        'home_warning_title'=> 'সতর্কবার্তা',
        'home_warning_text' => '১৮ বছরের নিচে অর্ডার করা সম্পূর্ণভাবে নিষিদ্ধ। তবুও কেউ অর্ডার করলে তার দায়ভার Code Zen কর্তৃপক্ষ বহন করবে না। নিয়ম ভঙ্গ করলে অ্যাকাউন্ট স্থায়ীভাবে ব্যান হতে পারে। এই শর্ত ভঙ্গ করলে ভবিষ্যতে কোনো সেবা দেওয়া হবে না।',
        'footer_about'      => 'কোন সমস্যায় পড়লে হোয়াটসঅ্যাপ এ যোগাযোগ করবেন। তাহলে দ্রুত সমাধান পেয়ে যাবেন।',
        'footer_copyright'  => '© Code Zen 2025 | All Rights Reserved | Developed by Code Zen Team',
        'rules_text'        => "শুধুমাত্র Bangladesh সার্ভারে ID Code দিয়ে টপ আপ হবে।\nPlayer ID Code ভুল দিয়ে Diamond না পেলে Code Zen কর্তৃপক্ষ দায়ী নয়।\nOrder কম্পিলিট হওয়ার পরেও আইডিতে ডায়মন্ড না পেলে চেক করার জন্য ID Pass দিতে হবে।\nঅর্ডার Cancel হলে কি কারণে তা Cancel হয়েছে তা অর্ডার হিস্টোরিতে দেওয়া থাকে অনুগ্রহ পূর্বক দেখে পুনরায় সঠিক তথ্য দিয়ে অর্ডার করবেন।",
        'app_show'          => '1',
        'app_name'          => 'Code Zen Topup App',
        'app_subtitle'      => 'Official Android App — Faster, Smoother, Anywhere',
        'app_features'      => "Lightning fast recharges\nSecure wallet & instant payments\nReal-time order tracking\nPush notifications for offers",
    ];
    $newCount = 0;
    foreach ($defaults as $k => $v) {
        if (setting($k) === null) { set_setting($k, $v); $newCount++; }
    }
    if ($newCount) $messages[] = "Inserted $newCount new default settings.";

    // ----------------------- DEFAULT ADMIN -----------------------
    $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM admin"); $stmt->execute();
    if ((int)$stmt->fetch()['c'] === 0) {
        $hash = password_hash('codezen@2025', PASSWORD_BCRYPT);
        $pdo->prepare("INSERT INTO admin (username, password) VALUES (?, ?)")->execute(['admin', $hash]);
        $messages[] = "Created default admin: <b>admin / codezen@2025</b>";
    }

    // ----------------------- SAMPLE GAMES -----------------------
    $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM categories"); $stmt->execute();
    if ((int)$stmt->fetch()['c'] === 0) {
        $cats = [
            ['Uid Topup [BD SERVER]','FREE FIRE','uid','Top up Diamonds directly to your Free Fire Bangladesh server account using your Player ID.',"1. Make sure your UID is correct.\n2. Diamonds will arrive within 5-10 minutes.\n3. No refund after delivery.",'https://placehold.co/400x400/1A8FBD/fff?text=UID+Topup'],
            ['Weeklg/Monthly','FREE FIRE','uid','Weekly & Monthly membership for Free Fire.',"Weekly: 5 days validity.\nMonthly: 30 days validity.",'https://placehold.co/400x400/F97316/fff?text=Weekly'],
            ['Evo Access [Uid]','FREE FIRE','uid','Evo Access pass for Free Fire.','Delivered within 10 minutes.','https://placehold.co/400x400/DC2626/fff?text=Evo'],
            ['Lavel UP PASS [BD]','FREE FIRE','uid','Level UP pass top-up via UID.','Instant delivery after payment.','https://placehold.co/400x400/0F1E3D/fff?text=Level+Up'],
            ['PUBG Mobile UC','PUBG MOBILE','uid','PUBG Mobile UC top-up using Character ID.',"1. Provide your correct PUBG Character ID.\n2. UC delivery within 10 minutes.",'https://placehold.co/400x400/F59E0B/fff?text=PUBG+UC'],
            ['Garena Voucher','VOUCHER CODE','voucher','Buy Garena voucher codes — redeemable on shop.garena.my.','Codes delivered after admin approval.','https://placehold.co/400x400/10B981/fff?text=Voucher'],
        ];
        $ins = $pdo->prepare("INSERT INTO categories (name, section, type, description, rules, image, zone_required, status, sort_order) VALUES (?,?,?,?,?,?,0,'active',?)");
        foreach ($cats as $i => $c) { $ins->execute([$c[0],$c[1],$c[2],$c[3],$c[4],$c[5],$i]); }
        $messages[] = "Inserted ".count($cats)." sample games.";

        $catIds = $pdo->query("SELECT id, type FROM categories ORDER BY id")->fetchAll();
        $pIns = $pdo->prepare("INSERT INTO products (cat_id, name, price, stock, sort_order, featured, status) VALUES (?,?,?,-1,?,?, 'active')");
        $samples = [
            ['25 Diamon', 20], ['50 Diamon', 36], ['100 Diamon', 72],
            ['115 Diamon', 77], ['240 Diamon', 152], ['355 Diamon', 229],
            ['480 Diamon', 300], ['505 Diamon', 320],
        ];
        foreach ($catIds as $c) {
            foreach ($samples as $i => $p) { $pIns->execute([$c['id'], $p[0], $p[1], $i, $i < 2 ? 1 : 0]); }
        }
        $messages[] = "Inserted sample products for each game.";
    }

    // ----------------------- SAMPLE PAYMENT METHODS -----------------------
    $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM payment_methods"); $stmt->execute();
    if ((int)$stmt->fetch()['c'] === 0) {
        $pms = [
            ['bKash','https://placehold.co/200x80/E2136E/fff?text=bKash','https://placehold.co/300x300/E2136E/fff?text=QR','01700000001','Send Money to this bKash number, then enter your number and TxnID below.'],
            ['Nagad','https://placehold.co/200x80/F58220/fff?text=Nagad','https://placehold.co/300x300/F58220/fff?text=QR','01700000002','Send Money to this Nagad number, then submit the TxnID.'],
            ['Rocket','https://placehold.co/200x80/8E2D89/fff?text=Rocket','https://placehold.co/300x300/8E2D89/fff?text=QR','017000000033','Send Money to this Rocket number with PIN.'],
        ];
        $ins = $pdo->prepare("INSERT INTO payment_methods (name, logo, qr_image, number, description, status, sort_order) VALUES (?,?,?,?,?, 'active',?)");
        foreach ($pms as $i => $p) $ins->execute([$p[0],$p[1],$p[2],$p[3],$p[4],$i]);
        $messages[] = "Inserted 3 sample payment methods.";
    }

    // ----------------------- SAMPLE SLIDER -----------------------
    $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM sliders"); $stmt->execute();
    if ((int)$stmt->fetch()['c'] === 0) {
        $sl = [
            ['https://placehold.co/1200x500/1A8FBD/fff?text=%F0%9F%92%AC+Topup+Issue%3F+%E2%80%94+Get+Support+Now', site_url('index.php')],
            ['https://placehold.co/1200x500/F97316/fff?text=Best+Rate+%E2%80%94+Instant+Diamond+Topup', site_url('index.php')],
            ['https://placehold.co/1200x500/0F1E3D/fff?text=24%2F7+Support+%E2%80%94+WhatsApp+%26+Telegram', site_url('addmoney.php')],
        ];
        $ins = $pdo->prepare("INSERT INTO sliders (image, link, sort_order, status) VALUES (?, ?, ?, 'active')");
        foreach ($sl as $i => $s) $ins->execute([$s[0], $s[1], $i]);
        $messages[] = "Inserted 3 sample sliders.";
    }

    // ----------------------- SAMPLE HELPLINES -----------------------
    $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM helplines"); $stmt->execute();
    if ((int)$stmt->fetch()['c'] === 0) {
        $hls = [
            ['Help line [9AM-12PM]','Whatsapp HelpLine','fa-whatsapp','https://wa.me/8801642667711',0],
            ['Help line [9AM-12PM]','টেলিগ্রামে সাপোর্ট','fa-telegram','https://t.me/codezen',1],
        ];
        $ins = $pdo->prepare("INSERT INTO helplines (title, subtitle, icon, link, sort_order, status) VALUES (?,?,?,?,?, 'active')");
        foreach ($hls as $h) $ins->execute($h);
        $messages[] = "Inserted 2 sample helplines.";
    }

    // ----------------------- DEMO USER -----------------------
    $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM users"); $stmt->execute();
    if ((int)$stmt->fetch()['c'] === 0) {
        $h = password_hash('demo1234', PASSWORD_BCRYPT);
        $pin = (string)random_int(10000, 99999);
        $pdo->prepare("INSERT INTO users (name, phone, email, password, balance, support_pin, status) VALUES (?,?,?,?,?,?, 'active')")
            ->execute(['Basic User', '01700000000', 'demo@codezen.app', $h, 100.00, $pin]);
        $messages[] = "Demo user created: <b>demo@codezen.app / demo1234</b>";
    }

    // Mark installed
    if (!is_dir(__DIR__ . '/data')) @mkdir(__DIR__ . '/data', 0775, true);
    @file_put_contents($lockFile, date('c'));

} catch (Throwable $e) { $errors[] = $e->getMessage(); }
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><title>Install — Code Zen Topup</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>body{font-family:'Poppins',sans-serif;}</style>
</head>
<body class="min-h-screen p-6" style="background:linear-gradient(135deg,#1A8FBD 0%,#0F1E3D 100%);color:#fff;">
<div class="max-w-2xl mx-auto bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 shadow-2xl">
  <h1 class="text-3xl font-extrabold mb-2">Code Zen Topup — Installer</h1>
  <p class="text-white/70 mb-6">Database driver: <b><?= e(db_driver()) ?></b></p>

  <?php if ($errors): ?>
    <div class="bg-red-500/20 border border-red-400 rounded-xl p-4 mb-4">
      <h3 class="font-bold mb-2">❌ Errors</h3>
      <?php foreach($errors as $err): ?><div>• <?= e($err) ?></div><?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="bg-emerald-500/20 border border-emerald-400 rounded-xl p-4 mb-4">
      <h3 class="font-bold mb-2">✅ Installation Complete</h3>
      <ul class="space-y-1 text-sm">
        <?php foreach ($messages as $m): ?><li>• <?= $m ?></li><?php endforeach; ?>
      </ul>
    </div>
    <div class="bg-white/5 rounded-xl p-4 mb-4 text-sm">
      <h3 class="font-bold mb-2">🔑 Default Logins</h3>
      <div>Admin: <code class="bg-black/30 px-2 py-1 rounded">admin / codezen@2025</code></div>
      <div class="mt-1">Demo user: <code class="bg-black/30 px-2 py-1 rounded">demo@codezen.app / demo1234</code></div>
    </div>
    <div class="flex gap-3">
      <a href="<?= site_url('index.php') ?>" class="flex-1 text-center bg-white text-[#0F1E3D] hover:opacity-90 px-6 py-3 rounded-xl font-bold">Go to App →</a>
      <a href="<?= site_url('zencp/login.php') ?>" class="flex-1 text-center bg-amber-500 hover:bg-amber-600 px-6 py-3 rounded-xl font-bold">Admin Panel →</a>
    </div>
    <p class="text-white/50 text-xs mt-4">Re-install: <code>install.php?reset=1</code> (drops all data!).</p>
  <?php endif; ?>
</div>
</body></html>
