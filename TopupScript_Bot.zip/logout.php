<?php
require_once __DIR__ . '/common/config.php';
unset($_SESSION['uid']);
session_regenerate_id(true);
header('Location: ' . site_url('login.php'));
exit;
