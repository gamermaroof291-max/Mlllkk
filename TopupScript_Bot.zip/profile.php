<?php
require_once __DIR__ . '/common/config.php';
require_login();
$me = current_user();

$msg = ''; $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) $err = 'Session expired.';
    elseif (($_POST['action'] ?? '') === 'profile') {
        $name  = sanitize($_POST['name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        if (!$name) { $err = 'Name required.'; }
        else {
            db()->prepare("UPDATE users SET name=?, email=? WHERE id=?")
                ->execute([$name, $email ?: null, $me['id']]);
            $msg = 'Profile updated.';
            $stmt = db()->prepare("SELECT * FROM users WHERE id=?"); $stmt->execute([$me['id']]); $me = $stmt->fetch();
        }
    } elseif (($_POST['action'] ?? '') === 'password') {
        $cur = $_POST['current'] ?? ''; $new = $_POST['new'] ?? ''; $new2 = $_POST['new2'] ?? '';
        if (!password_verify($cur, $me['password'])) $err = 'Current password incorrect.';
        elseif (strlen($new) < 6) $err = 'New password must be 6+ chars.';
        elseif ($new !== $new2) $err = 'Passwords do not match.';
        else {
            db()->prepare("UPDATE users SET password=? WHERE id=?")
                ->execute([password_hash($new, PASSWORD_BCRYPT), $me['id']]);
            $msg = 'Password updated successfully.';
        }
    }
}

$weekTs = strtotime('-7 days');
$st = db()->prepare("SELECT
  (SELECT COUNT(*) FROM orders WHERE user_id=?) AS total_orders,
  (SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE user_id=? AND status='completed') AS total_spent,
  (SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE user_id=? AND status='completed' AND created_at>=?) AS week_spent");
$st->execute([$me['id'], $me['id'], $me['id'], date('Y-m-d H:i:s', $weekTs)]);
$stats = $st->fetch();

$pageTitle = 'My Account — ' . setting('site_name');
require __DIR__ . '/common/header.php';
$sym = setting('currency_symbol','৳');
?>

<div class="text-center pt-3 pb-2">
  <div class="inline-block relative">
    <div class="w-24 h-24 rounded-full bg-[#6B5BD9] text-white text-4xl font-extrabold flex items-center justify-center mx-auto ring-[6px] ring-brandSoft shadow-lg">
      <?= e(strtoupper(substr($me['name'],0,1))) ?>
    </div>
  </div>
  <div class="mt-3 text-brand font-bold text-lg">Hi, <?= e($me['name']) ?></div>
  <div class="text-ink font-bold text-base mt-0.5">Available Balance : <?= number_format((float)$me['balance'],0) ?> <?= e($sym) ?>
    <button onclick="location.reload()" class="ml-1 text-muted text-sm"><i class="fa-solid fa-arrows-rotate"></i></button>
  </div>
</div>

<div class="grid grid-cols-2 gap-3 my-4">
  <div class="card p-4 text-center">
    <div class="text-brand font-extrabold text-2xl"><?= e($me['support_pin']) ?></div>
    <div class="text-ink font-bold text-sm mt-1">Support Pin</div>
  </div>
  <div class="card p-4 text-center">
    <div class="text-brand font-extrabold text-2xl"><?= number_format((float)$stats['week_spent'],0) ?> <?= e($sym) ?></div>
    <div class="text-ink font-bold text-sm mt-1">Weekly Spent</div>
  </div>
  <div class="card p-4 text-center">
    <div class="text-brand font-extrabold text-2xl"><?= number_format((float)$stats['total_spent'],0) ?></div>
    <div class="text-ink font-bold text-sm mt-1">Total Spent</div>
  </div>
  <div class="card p-4 text-center">
    <div class="text-brand font-extrabold text-2xl"><?= (int)$stats['total_orders'] ?></div>
    <div class="text-ink font-bold text-sm mt-1">Total Order</div>
  </div>
</div>

<div class="card p-4 mb-4">
  <h3 class="font-extrabold text-[15px] text-ink mb-3 flex items-center gap-2"><i class="fa-solid fa-folder text-brand"></i>Account Information</h3>
  <div class="bg-brand text-white text-center font-bold py-3 rounded-lg mb-2"><?= number_format((float)$me['balance'],2) ?><?= e($sym) ?></div>
  <div class="text-center font-extrabold text-ink mb-3">Available Balance</div>

  <?php if ($msg): ?><div class="bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-lg p-2 mb-2 text-sm"><?= e($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="bg-rose-50 border border-rose-200 text-rose-700 rounded-lg p-2 mb-2 text-sm"><?= e($err) ?></div><?php endif; ?>

  <div class="flex gap-2 mb-3 mt-2">
    <button class="tab-btn flex-1 py-2 font-bold text-xs rounded-lg bg-brand text-white" data-tab="info">Profile</button>
    <button class="tab-btn flex-1 py-2 font-bold text-xs rounded-lg bg-[#F0F4FA] text-ink" data-tab="pass">Password</button>
  </div>

  <div data-pane="info">
    <form method="post" class="space-y-3">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="profile">
      <div><label class="text-xs font-bold uppercase text-muted">Full name</label><input name="name" class="input mt-1" value="<?= e($me['name']) ?>" required></div>
      <div><label class="text-xs font-bold uppercase text-muted">Phone</label><input class="input mt-1 opacity-60" value="<?= e($me['phone']) ?>" disabled></div>
      <div><label class="text-xs font-bold uppercase text-muted">Email</label><input name="email" type="email" class="input mt-1" value="<?= e($me['email']) ?>"></div>
      <button class="btn-blue"><i class="fa-solid fa-floppy-disk"></i>Save Changes</button>
    </form>
  </div>

  <div data-pane="pass" class="hidden">
    <form method="post" class="space-y-3">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="password">
      <div><label class="text-xs font-bold uppercase text-muted">Current password</label><input name="current" type="password" class="input mt-1" required></div>
      <div><label class="text-xs font-bold uppercase text-muted">New password</label><input name="new" type="password" class="input mt-1" required></div>
      <div><label class="text-xs font-bold uppercase text-muted">Confirm new password</label><input name="new2" type="password" class="input mt-1" required></div>
      <button class="btn-blue"><i class="fa-solid fa-shield-halved"></i>Update Password</button>
    </form>
  </div>
</div>

<a href="<?= e(site_url('app.php')) ?>" class="card p-3 mb-3 flex items-center gap-3">
  <div class="w-10 h-10 rounded-lg bg-brandSoft text-brand flex items-center justify-center"><i class="fa-brands fa-android text-lg"></i></div>
  <div class="flex-1"><div class="font-bold text-ink text-sm">Get our Android App</div><div class="text-xs text-muted">Faster checkout & push offers</div></div>
  <i class="fa-solid fa-chevron-right text-muted"></i>
</a>

<a href="<?= e(site_url('logout.php')) ?>" class="card p-3 mb-3 flex items-center gap-3">
  <div class="w-10 h-10 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center"><i class="fa-solid fa-right-from-bracket"></i></div>
  <div class="flex-1"><div class="font-bold text-ink text-sm">Logout</div><div class="text-xs text-muted">Sign out from this device</div></div>
  <i class="fa-solid fa-chevron-right text-muted"></i>
</a>

<script>
document.querySelectorAll('.tab-btn').forEach(b=>{
  b.addEventListener('click', function(){
    document.querySelectorAll('.tab-btn').forEach(x=>{ x.classList.remove('bg-brand','text-white'); x.classList.add('bg-[#F0F4FA]','text-ink'); });
    b.classList.add('bg-brand','text-white'); b.classList.remove('bg-[#F0F4FA]','text-ink');
    var t=b.dataset.tab;
    document.querySelectorAll('[data-pane]').forEach(p=>p.classList.toggle('hidden', p.dataset.pane!==t));
  });
});
</script>
<?php require __DIR__ . '/common/footer.php'; ?>
