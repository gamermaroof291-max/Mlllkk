<?php
require_once __DIR__ . '/common/config.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) $err = 'Session expired. Please try again.';
    else {
        $id = trim($_POST['identifier'] ?? '');
        $pw = $_POST['password'] ?? '';
        if (!$id || !$pw) $err = 'Please fill in all fields.';
        else {
            $stmt = db()->prepare("SELECT * FROM users WHERE phone=? OR email=? LIMIT 1");
            $stmt->execute([$id, $id]);
            $u = $stmt->fetch();
            if (!$u || !password_verify($pw, $u['password'])) $err = 'Invalid login. Check phone/email & password.';
            elseif (($u['status'] ?? 'active') !== 'active') $err = 'Your account is suspended. Contact support.';
            else { $_SESSION['uid'] = $u['id']; header('Location: ' . site_url('index.php')); exit; }
        }
    }
}
if (current_user()) { header('Location: ' . site_url('index.php')); exit; }
$pageTitle = 'Login — ' . setting('site_name');
require __DIR__ . '/common/header.php';
?>
<div class="card p-6 mt-2">
  <div class="text-center mb-5">
    <div class="inline-flex w-14 h-14 rounded-2xl text-white items-center justify-center text-xl font-extrabold shadow mb-3" style="background:linear-gradient(135deg,var(--c-brand),var(--c-navy));">CZ</div>
    <h1 class="text-xl font-extrabold text-ink">Welcome Back</h1>
    <p class="text-sm text-muted mt-1">Login to top up your favorite games</p>
  </div>
  <?php if ($err): ?><div class="bg-rose-50 border border-rose-200 text-rose-700 rounded-lg p-3 mb-3 text-sm"><i class="fa-solid fa-circle-exclamation mr-1"></i><?= e($err) ?></div><?php endif; ?>
  <form method="post" class="space-y-3">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <div><label class="text-xs font-bold uppercase text-muted">Phone or Email</label>
      <input name="identifier" class="input mt-1" placeholder="01XXXXXXXXX or you@email.com" required value="<?= e($_POST['identifier'] ?? '') ?>"></div>
    <div><label class="text-xs font-bold uppercase text-muted">Password</label>
      <div class="relative">
        <input name="password" type="password" id="pw" class="input mt-1 pr-12" placeholder="••••••••" required>
        <button type="button" onclick="var p=document.getElementById('pw');p.type=p.type==='password'?'text':'password';" class="absolute right-3 top-1/2 -translate-y-1/2 text-muted mt-0.5"><i class="fa-solid fa-eye"></i></button>
      </div></div>
    <button class="btn-blue mt-2"><i class="fa-solid fa-right-to-bracket"></i>Login</button>
  </form>
  <div class="text-center mt-4 text-sm text-ink">Don't have an account? <a href="<?= e(site_url('register.php')) ?>" class="text-brand font-bold">Sign up</a></div>
  <div class="text-center mt-2 text-xs text-muted">Demo: <code class="bg-[#F0F4FA] px-2 py-0.5 rounded">demo@codezen.app / demo1234</code></div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>
