<?php
require_once __DIR__ . '/common/config.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT * FROM app_versions WHERE id=? AND status='active'");
$stmt->execute([$id]);
$v = $stmt->fetch();
if (!$v) { header('Location: '.site_url('app.php')); exit; }

$file = __DIR__ . '/' . ltrim($v['file_path'], '/');
if (!file_exists($file)) { header('Location: '.site_url('app.php')); exit; }

db()->prepare("UPDATE app_versions SET downloads = downloads + 1 WHERE id=?")->execute([$id]);

$base = preg_replace('/[^A-Za-z0-9_.-]/','_', setting('site_name','codezen'));
$fname = $base . '-v' . $v['version'] . '.apk';

header('Content-Type: application/vnd.android.package-archive');
header('Content-Disposition: attachment; filename="'.$fname.'"');
header('Content-Length: '.filesize($file));
header('Cache-Control: no-cache');
readfile($file);
exit;
