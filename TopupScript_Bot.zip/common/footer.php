</main>

<?php
try { 
    $helplines = db()->query("SELECT * FROM helplines WHERE status='active' ORDER BY sort_order, id")->fetchAll(); 
} catch(Throwable $e) { 
    $helplines = []; 
}

/**
 * STRONGEST ANTI-TAMPER CREDIT LOCK
 * জনি কেউ এই নাম বা লিংক পরিবর্তন করে, তবে সাইট সাথে সাথে লক হয়ে যাবে।
 */
$developer_name = "TEAM JHHX";
$developer_link = "https://t.me/JHx_Technical_Creator";

if ($developer_name !== "TEAM JHHX" || $developer_link !== "https://t.me/JHx_Technical_Creator" || !isset($developer_name) || !isset($developer_link)) {
    die("<div style='position:fixed;top:0;left:0;width:100%;height:100%;background:#0f172a;color:#ef4444;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:sans-serif;padding:20px;box-sizing:border-box;z-index:999999;text-align:center;'>
        <h1 style='font-size:26px;margin-bottom:10px;font-weight:800;'>SECURITY ALERT</h1>
        <p style='font-size:16px;color:#cbd5e1;max-width:500px;line-height:1.6;'>Unauthorised Modification Detected! Core developer credit configuration has been removed or modified. Website functionality has been suspended automatically.</p>
    </div>");
}
?>

<footer class="bg-navy text-white pt-10 pb-28 mt-4 border-t border-white/5 rounded-t-[24px]">
  <div class="max-w-md mx-auto px-5">
    
    <h3 class="text-xs font-bold tracking-[0.2em] text-brandSoft/50 uppercase mb-3 text-center">STAY CONNECTED</h3>
    <p class="text-white/80 text-sm leading-relaxed mb-5 text-center px-4">
      <?= e(setting('footer_about','Get in touch on WhatsApp for fast support.')) ?>
      <?php if (setting('support_phone')): ?>
        <span class="block mt-1 font-bold text-lg text-orange"><?= e(setting('support_phone')) ?></span>
      <?php endif; ?>
    </p>

    <div class="flex justify-center gap-3 mb-8">
      <?php
      $socials = [
        ['fa-facebook-f', setting('facebook_url')],
        ['fa-instagram',  setting('instagram_url')],
        ['fa-youtube',    setting('youtube_url')],
        ['fa-envelope',   setting('support_email') ? 'mailto:'.setting('support_email') : ''],
      ];
      foreach ($socials as $s): if (!$s[1]) continue; ?>
        <a href="<?= e($s[1]) ?>" target="_blank" rel="noopener" class="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-brand hover:border-brand hover:-translate-y-0.5 transition-all duration-200 shadow-sm">
          <i class="<?= str_starts_with($s[0],'fa-envelope')?'fa-solid':'fa-brands' ?> <?= e($s[0]) ?> text-base"></i>
        </a>
      <?php endforeach; ?>
    </div>

    <?php if ($helplines): ?>
    <div class="mb-8">
      <h3 class="text-xs font-bold tracking-[0.2em] text-brandSoft/50 uppercase mb-4 text-center">SUPPORT CENTER</h3>
      <div class="space-y-2.5">
        <?php foreach ($helplines as $h): ?>
          <a href="<?= e($h['link'] ?: '#') ?>" target="_blank" rel="noopener" class="flex items-center gap-3.5 p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 hover:bg-white/[0.06] hover:border-white/20 transition-all duration-200">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-brand/20 to-brand/5 border border-brand/30 flex items-center justify-center text-brand text-base flex-shrink-0">
              <i class="<?= (str_contains($h['icon'] ?? '','wha')||str_contains($h['icon'] ?? '','tele')||str_contains($h['icon'] ?? '','face')||str_contains($h['icon'] ?? '','insta')||str_contains($h['icon'] ?? '','you'))?'fa-brands':'fa-solid' ?> <?= e($h['icon'] ?: 'fa-phone') ?>"></i>
            </div>
            <div class="flex-1 min-w-0">
              <div class="font-bold text-[14px] text-white/90 leading-tight mb-0.5"><?= e($h['title']) ?></div>
              <div class="text-white/50 text-xs truncate"><?= e($h['subtitle']) ?></div>
            </div>
            <i class="fa-solid fa-chevron-right text-xs text-white/20 pr-1"></i>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="relative overflow-hidden my-6 p-4 rounded-2xl bg-gradient-to-r from-brand/10 via-white/[0.02] to-brand/10 border border-brand/20 text-center shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]">
        <div class="absolute -right-6 -bottom-6 w-16 h-16 bg-brand/10 rounded-full blur-xl pointer-events-none"></div>
        <div class="absolute -left-6 -top-6 w-16 h-16 bg-orange/10 rounded-full blur-xl pointer-events-none"></div>
        
        <span class="text-[10px] font-bold tracking-[0.25em] text-white/40 block mb-1.5 uppercase">SYSTEM DEVELOPED BY</span>
        <a href="<?= $developer_link ?>" target="_blank" rel="noopener" class="inline-flex items-center gap-2 group">
            <span class="text-base font-extrabold tracking-wider bg-gradient-to-r from-blue-400 via-indigo-300 to-orange bg-clip-text text-transparent group-hover:opacity-90 transition-opacity">
                <?= $developer_name ?>
            </span>
            <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-blue-500/10 text-blue-400 text-[10px] border border-blue-500/25 group-hover:bg-blue-500/20 group-hover:text-blue-300 transition-all">
                <i class="fa-solid fa-paper-plane"></i>
            </span>
        </a>
    </div>

    <div class="border-t border-white/5 mt-6 pt-5 text-center text-xs text-white/40 tracking-wide">
      <?= e(setting('footer_copyright', '© '.setting('site_name').' '.date('Y'))) ?>
    </div>
    
  </div>
</footer>

<?php require __DIR__ . '/bottom.php'; ?>
</body>
</html>