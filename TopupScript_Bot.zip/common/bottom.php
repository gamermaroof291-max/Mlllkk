<?php
$me  = current_user();
$cur = basename($_SERVER['SCRIPT_NAME'] ?? '');
$bn  = function($f, $cur){ return in_array($cur,(array)$f) ? 'text-brand' : 'text-[#6B7280]'; };
$fabLink  = setting('fab_link', '#');
$fabIcon  = setting('fab_icon', 'fa-phone');
$fabLabel = setting('fab_label', 'সাহায্য লাগবে ?');
$fabShow  = setting('fab_label_show', '1') === '1';

/**
 * FIXED LOCK INTEGRITY SYSTEM
 */
$b_check_name = "TEAM JHHX";
$b_check_link = "https://t.me/JHx_Technical_Creator";

if ($b_check_name !== "TEAM JHHX" || $b_check_link !== "https://t.me/JHx_Technical_Creator") {
    die("<div style='text-align:center; padding:50px; font-family:sans-serif; color:#DC2626; font-weight:bold; background:#FFF5F5; position:fixed; inset:0; z-index:99999;'>Error: Core credit configuration has been removed or modified. Website functionality suspended.</div>");
}
?>
<div class="fixed right-4 bottom-24 z-40 flex items-center gap-2">
  <?php if ($fabShow && $fabLabel): ?>
    <a href="<?= e($fabLink) ?>" target="_blank" rel="noopener" class="bg-[#DC2626] text-white text-xs font-bold px-3 py-2 rounded-md shadow-lg whitespace-nowrap">
      <?= e($fabLabel) ?>
    </a>
  <?php endif; ?>
  <a href="<?= e($fabLink) ?>" target="_blank" rel="noopener" class="w-12 h-12 rounded-full bg-[#DC2626] text-white flex items-center justify-center text-lg shadow-2xl fab-pulse" aria-label="Live support">
    <i class="fa-solid <?= e($fabIcon) ?>"></i>
  </a>
</div>

<nav class="fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-[#E5ECF5] shadow-[0_-4px_18px_rgba(15,30,61,.06)]">
  <div class="max-w-md mx-auto grid grid-cols-5">
    <a href="<?= e(site_url('index.php')) ?>" class="flex flex-col items-center gap-0.5 py-2.5 <?= $bn(['index.php'], $cur) ?>">
      <i class="fa-solid fa-house text-[20px]"></i><span class="text-[11px] font-semibold">Home</span>
    </a>
    <a href="<?= e(site_url('addmoney.php')) ?>" class="flex flex-col items-center gap-0.5 py-2.5 <?= $bn(['addmoney.php'], $cur) ?>">
      <i class="fa-solid fa-square-plus text-[20px]"></i><span class="text-[11px] font-semibold">Add Money</span>
    </a>
    <a href="<?= e(site_url('order.php')) ?>" class="flex flex-col items-center gap-0.5 py-2.5 <?= $bn(['order.php'], $cur) ?>">
      <i class="fa-regular fa-bookmark text-[20px]"></i><span class="text-[11px] font-semibold">My Orders</span>
    </a>
    <a href="<?= e(site_url('mycode.php')) ?>" class="flex flex-col items-center gap-0.5 py-2.5 <?= $bn(['mycode.php'], $cur) ?>">
      <i class="fa-solid fa-table-cells-large text-[20px]"></i><span class="text-[11px] font-semibold">My Codes</span>
    </a>
    <a href="<?= e(site_url($me ? 'profile.php' : 'login.php')) ?>" class="flex flex-col items-center gap-0.5 py-2.5 <?= $bn(['profile.php','login.php','register.php'], $cur) ?>">
      <i class="fa-regular fa-circle-user text-[20px]"></i><span class="text-[11px] font-semibold">My Account</span>
    </a>
  </div>
</nav>