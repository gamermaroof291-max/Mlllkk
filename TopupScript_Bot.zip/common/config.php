<?php
/**
 * Code Zen Topup - Configuration & DB Helpers
 * --------------------------------------------------
 * For free hosting (InfinityFree / ProFreeHost / Hostinger / etc.),
 * just edit the MySQL block below with your cPanel database details
 * and re-visit /install.php in your browser.
 *
 * For local dev (no MySQL available), the app falls back to SQLite
 * automatically — zero config needed.
 */

// ===================== EDIT FOR YOUR HOSTING =====================
$DB_DRIVER = 'auto';   // 'auto' | 'mysql' | 'sqlite'

$MYSQL_HOST = 'localhost';   // ← your MySQL host (from cPanel)
$MYSQL_USER = 'dbuser';              // ← your MySQL username
$MYSQL_PASS = 'dbpass';        // ← your MySQL password
$MYSQL_DB   = 'dbname';      // ← your MySQL database name
$MYSQL_PORT = 3306;
// ==================================================================

date_default_timezone_set('Asia/Dhaka');
mb_internal_encoding('UTF-8');
ini_set('display_errors', '0');
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 60 * 60 * 24 * 7,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// ---------- Site root URL (works on subfolder hosting too) ----------
function site_url(string $path = ''): string {
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    // Strip the file part to get directory the app lives in
    $dir = rtrim(str_replace('\\', '/', dirname($script)), '/');
    // If we're inside /api/ or /zencp/, walk up
    while (str_ends_with($dir, '/api') || str_ends_with($dir, '/zencp') || str_ends_with($dir, '/zencp/common') || str_ends_with($dir, '/common')) {
        $dir = rtrim(substr($dir, 0, strrpos($dir, '/')), '/');
    }
    if ($dir === '' || $dir === '.') $dir = '';
    return $dir . '/' . ltrim($path, '/');
}

// ---------- Database connection (PDO) ----------
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    global $DB_DRIVER, $MYSQL_HOST, $MYSQL_USER, $MYSQL_PASS, $MYSQL_DB, $MYSQL_PORT;

    $useMysql = false;
    if ($DB_DRIVER === 'mysql') $useMysql = true;
    elseif ($DB_DRIVER === 'auto' && extension_loaded('pdo_mysql')) {
        // Try MySQL first, fall back to SQLite if connection fails
        try {
            $pdo = new PDO(
                "mysql:host={$MYSQL_HOST};port={$MYSQL_PORT};dbname={$MYSQL_DB};charset=utf8mb4",
                $MYSQL_USER, $MYSQL_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                 PDO::ATTR_EMULATE_PREPARES => false,
                 PDO::ATTR_TIMEOUT => 3]
            );
            return $pdo;
        } catch (Throwable $e) {
            $useMysql = false;
        }
    }

    if ($useMysql) {
        $pdo = new PDO(
            "mysql:host={$MYSQL_HOST};port={$MYSQL_PORT};dbname={$MYSQL_DB};charset=utf8mb4",
            $MYSQL_USER, $MYSQL_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
             PDO::ATTR_EMULATE_PREPARES => false]
        );
        return $pdo;
    }

    // SQLite fallback (Replit preview)
    $sqlitePath = __DIR__ . '/../data/codezen.sqlite';
    if (!is_dir(dirname($sqlitePath))) @mkdir(dirname($sqlitePath), 0775, true);
    $pdo = new PDO('sqlite:' . $sqlitePath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON');
    return $pdo;
}

function db_driver(): string {
    return db()->getAttribute(PDO::ATTR_DRIVER_NAME); // 'mysql' or 'sqlite'
}

// ---------- Helpers ----------
function e(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function sanitize(?string $s): string { return strip_tags(trim((string)$s)); }
function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['_csrf'];
}
function csrf_check(?string $t): bool { return is_string($t) && hash_equals($_SESSION['_csrf'] ?? '', $t); }
function gen_txn(string $prefix = 'CZ'): string {
    return $prefix . strtoupper(bin2hex(random_bytes(4)));
}
function format_money($n): string {
    $sym = setting('currency_symbol', '৳');
    return $sym . number_format((float)$n, 2);
}
function time_ago($ts): string {
    $t = is_numeric($ts) ? (int)$ts : strtotime((string)$ts);
    if (!$t) return '';
    $d = time() - $t;
    if ($d < 60) return $d . 's ago';
    if ($d < 3600) return floor($d/60) . 'm ago';
    if ($d < 86400) return floor($d/3600) . 'h ago';
    if ($d < 2592000) return floor($d/86400) . 'd ago';
    return date('M j, Y', $t);
}

function setting(string $key, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (db()->query("SELECT key_name, value FROM settings") as $r) {
                $cache[$r['key_name']] = $r['value'];
            }
        } catch (Throwable $e) { /* table may not exist yet */ }
    }
    return $cache[$key] ?? $default;
}

function set_setting(string $key, $value): void {
    $pdo = db();
    if (db_driver() === 'mysql') {
        $stmt = $pdo->prepare("INSERT INTO settings (key_name, value) VALUES (?, ?)
                               ON DUPLICATE KEY UPDATE value = VALUES(value)");
        $stmt->execute([$key, (string)$value]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO settings (key_name, value) VALUES (?, ?)
                               ON CONFLICT(key_name) DO UPDATE SET value = excluded.value");
        $stmt->execute([$key, (string)$value]);
    }
}

function current_user(): ?array {
    if (empty($_SESSION['uid'])) return null;
    static $u = null;
    if ($u !== null) return $u;
    $stmt = db()->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['uid']]);
    $u = $stmt->fetch() ?: null;
    return $u;
}
function require_login(): void {
    if (!current_user()) { header('Location: ' . site_url('login.php')); exit; }
}
function admin_user(): ?array {
    if (empty($_SESSION['aid'])) return null;
    $stmt = db()->prepare("SELECT * FROM admin WHERE id = ?");
    $stmt->execute([$_SESSION['aid']]);
    return $stmt->fetch() ?: null;
}
function require_admin(): void {
    if (!admin_user()) { header('Location: ' . site_url('zencp/login.php')); exit; }
}

// ---------- JSON API helpers ----------
function json_response($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function json_ok(string $msg = 'OK', $data = null): void { json_response(['success'=>true,'message'=>$msg,'data'=>$data]); }
function json_err(string $msg, int $status = 400, $data = null): void { json_response(['success'=>false,'message'=>$msg,'data'=>$data], $status); }
function json_input(): array {
    $raw = file_get_contents('php://input');
    if ($raw && ($d = json_decode($raw, true)) && is_array($d)) return $d;
    return $_POST;
}

// ---------- Upload helper ----------
function save_upload(array $file, string $subfolder = 'misc', int $maxBytes = 2*1024*1024): ?string {
    if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return null;
    if ($file['size'] > $maxBytes) return null;
    $info = getimagesize($file['tmp_name']);
    if (!$info) return null;
    $ext = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'][$info['mime']] ?? null;
    if (!$ext) return null;
    $dir = __DIR__ . '/../uploads/' . $subfolder;
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) return null;
    return 'uploads/' . $subfolder . '/' . $name;
}
