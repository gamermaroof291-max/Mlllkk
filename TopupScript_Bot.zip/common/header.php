<?php
require_once __DIR__ . '/config.php';
$me = current_user();
$siteName  = setting('site_name', 'Code Zen Topup');
$siteTitle = setting('site_title', $siteName);
$pageTitle = $pageTitle ?? $siteTitle;
$primary   = setting('primary_color', '#1A8FBD');
$accent    = setting('accent_color',  '#F97316');
$navy      = setting('navy_color',    '#0F1E3D');
$logoText  = setting('logo_text', 'Code Zen');
$logoTag   = setting('logo_tag',  'TOPUP');
$logoImg   = setting('logo_image', '');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="theme-color" content="<?= e($primary) ?>">
<meta name="description" content="<?= e(setting('site_description','')) ?>">
<title><?= e($pageTitle) ?></title>

<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config = { theme: { extend: { colors: {
  brand: '<?= e($primary) ?>', brandDark: '#1A6F94', brandSoft: '#E8F4FB',
  step: '#1E5C8A', orange: '<?= e($accent) ?>',
  navy: '<?= e($navy) ?>', ink: '#1A2332', muted: '#6B7280',
  page: '#F0F4FA', ringSoft: '#D7E3F2'
}, fontFamily: { sans: ['Poppins','Inter','system-ui'] } } } };
</script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root { --c-brand: <?= e($primary) ?>; --c-orange: <?= e($accent) ?>; --c-navy: <?= e($navy) ?>; }
html, body { font-family: 'Poppins','Inter', sans-serif; }
body { background:#F0F4FA; color:#1A2332; min-height:100vh; -webkit-tap-highlight-color:transparent; }
.card { background:#fff; border:1px solid #E5ECF5; border-radius:14px; box-shadow:0 1px 2px rgba(15,30,61,.04); }
.card-soft { background:#fff; border-radius:12px; }
.btn-blue { background:var(--c-brand); color:#fff; font-weight:600; border-radius:10px; padding:.85rem 1rem; display:inline-flex; align-items:center; justify-content:center; gap:.4rem; transition:filter .2s,transform .15s; border:none; cursor:pointer; width:100%; }
.btn-blue:hover { filter:brightness(1.05); }
.btn-blue:active { transform:translateY(1px); }
.btn-blue:disabled { opacity:.55; cursor:not-allowed; }
.btn-red { background:#DC2626; color:#fff; font-weight:600; border-radius:8px; padding:.55rem 1rem; display:inline-flex; align-items:center; gap:.4rem; border:none; cursor:pointer; }
.input { width:100%; padding:.85rem 1rem; border-radius:10px; background:#fff; border:1px solid #D7E3F2; color:#1A2332; font-size:14px; transition:border-color .15s,box-shadow .15s; }
.input:focus { outline:none; border-color:var(--c-brand); box-shadow:0 0 0 3px rgba(26,143,189,.15); }
.step-num { width:26px; height:26px; border-radius:50%; background:#1E5C8A; color:#fff; font-weight:700; font-size:13px; display:inline-flex; align-items:center; justify-content:center; box-shadow:0 2px 6px rgba(30,92,138,.3); }
.section-title { display:flex; align-items:center; gap:8px; font-weight:700; font-size:16px; color:var(--c-navy); }

.pack { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:12px 14px; background:#fff; border:1.5px solid #E5ECF5; border-radius:10px; cursor:pointer; transition:all .15s; }
.pack:hover { border-color:#C7D6E8; }
.pack .dot { width:18px; height:18px; border-radius:50%; border:1.5px solid #C7D6E8; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; font-size:10px; color:#fff; }
.pack .name { font-size:13.5px; color:#1A2332; font-weight:500; }
.pack .price { font-size:13px; font-weight:700; color:#9CA3AF; }
.pack.selected { border-color:var(--c-orange); background:#FFF5EE; box-shadow:0 2px 8px rgba(249,115,22,.12); }
.pack.selected .dot { border-color:var(--c-orange); background:var(--c-orange); }
.pack.selected .price { color:var(--c-orange); }

.payopt { background:#fff; border:1.5px solid #E5ECF5; border-radius:12px; overflow:hidden; cursor:pointer; transition:all .15s; position:relative; }
.payopt:hover { border-color:#C7D6E8; }
.payopt .body { padding:18px; min-height:96px; display:flex; align-items:center; justify-content:center; }
.payopt .label { background:#E5ECF5; color:#1A2332; font-size:13px; font-weight:600; padding:8px; text-align:center; }
.payopt.selected { border-color:var(--c-orange); }
.payopt.selected::before { content:""; position:absolute; top:0; left:0; width:0; height:0; border-top:34px solid var(--c-orange); border-right:34px solid transparent; z-index:1; }
.payopt.selected::after { content:"\f00c"; font-family:"Font Awesome 6 Free"; font-weight:900; position:absolute; top:3px; left:5px; color:#fff; font-size:11px; z-index:2; }

.pill { padding:3px 10px; border-radius:999px; font-size:11px; font-weight:700; }
.toast { position:fixed; left:50%; bottom:130px; transform:translateX(-50%); padding:.75rem 1.2rem; border-radius:12px; color:#fff; font-weight:500; z-index:80; box-shadow:0 8px 24px rgba(0,0,0,.2); }
.dot-loader{display:inline-flex;gap:6px;}
.dot-loader span{width:8px;height:8px;background:#fff;border-radius:50%;animation:dotbounce 1.2s infinite ease-in-out both;}
.dot-loader span:nth-child(2){animation-delay:.15s;} .dot-loader span:nth-child(3){animation-delay:.3s;}
@keyframes dotbounce{0%,80%,100%{transform:scale(.6);opacity:.5;}40%{transform:scale(1);opacity:1;}}
@keyframes fadeUp { from {opacity:0; transform:translateY(8px);} to {opacity:1; transform:none;} }
.fade-in { animation: fadeUp .35s ease both; }

.marquee { overflow:hidden; white-space:nowrap; }
.marquee-inner { display:inline-block; padding-left:100%; animation: scroll 28s linear infinite; }
@keyframes scroll { 0%{transform:translateX(0);} 100%{transform:translateX(-100%);} }

.fab-pulse { animation: fpulse 2s infinite; }
@keyframes fpulse { 0%,100%{box-shadow:0 6px 20px rgba(220,38,38,.45),0 0 0 0 rgba(220,38,38,.35);} 50%{box-shadow:0 6px 20px rgba(220,38,38,.55),0 0 0 14px rgba(220,38,38,0);} }

::-webkit-scrollbar { width:6px; height:6px; }
::-webkit-scrollbar-thumb { background:#C7D6E8; border-radius:8px; }

.sec-cap { font-size:18px; font-weight:800; color:var(--c-navy); letter-spacing:.5px; text-align:center; }
</style>
</head>
<body>

<?php if (setting('marquee_enabled','1') === '1' && setting('marquee_text')): ?>
<div class="bg-gradient-to-r from-[#0F1E3D] to-[#1A8FBD] text-white text-xs py-1.5 marquee">
  <span class="marquee-inner"><?= e(setting('marquee_text')) ?> &nbsp; • &nbsp; <?= e(setting('marquee_text')) ?></span>
</div>
<?php endif; ?>

<header class="sticky top-0 z-30 bg-white border-b border-[#E5ECF5]">
  <div class="max-w-md mx-auto flex items-center justify-between px-4 py-2.5">
    <a href="<?= e(site_url('index.php')) ?>" class="flex items-center gap-1.5">
      <?php if ($logoImg): ?>
        <img src="<?= e(site_url($logoImg)) ?>" alt="" class="h-9">
      <?php else: ?>
        <div class="w-9 h-9 rounded-lg text-white font-extrabold flex items-center justify-center shadow-sm" style="background:linear-gradient(135deg,var(--c-brand),var(--c-navy));"><?= e(strtoupper(substr($logoText,0,2))) ?></div>
        <div class="leading-none">
          <div class="font-extrabold text-[18px] text-ink tracking-tight"><?= e(explode(' ', $logoText)[0]) ?> <span class="text-brand"><?= e(trim(substr($logoText, strlen(explode(' ', $logoText)[0])))) ?: '' ?></span></div>
          <div class="text-[9px] tracking-widest text-brand font-bold mt-0.5"><?= e($logoTag) ?></div>
        </div>
      <?php endif; ?>
    </a>
    <div class="flex items-center gap-2">
      <a href="<?= e(site_url('addmoney.php')) ?>" class="bg-brand text-white px-3 py-1.5 rounded-full font-bold text-sm flex items-center gap-1.5 shadow-sm">
        <i class="fa-solid fa-wallet"></i>
        <span><?= $me ? number_format((float)$me['balance'],0) : '0' ?><?= e(setting('currency_symbol','৳')) ?></span>
      </a>
      <?php if ($me): ?>
        <a href="<?= e(site_url('profile.php')) ?>" class="w-9 h-9 rounded-full bg-[#6B5BD9] text-white font-bold flex items-center justify-center text-sm shadow-sm"><?= e(strtoupper(substr($me['name'],0,1))) ?></a>
      <?php else: ?>
        <a href="<?= e(site_url('login.php')) ?>" class="w-9 h-9 rounded-full bg-[#6B5BD9] text-white font-bold flex items-center justify-center text-sm shadow-sm"><i class="fa-solid fa-user"></i></a>
      <?php endif; ?>
    </div>
  </div>
</header>

<main class="max-w-md mx-auto px-3 pt-3 pb-32 fade-in">
<script>
window.czToast = function(msg, kind){
  kind = kind || 'info';
  var bg = { success:'#10B981', error:'#EF4444', warn:'#F59E0B', info:'#1A8FBD' }[kind] || '#1A8FBD';
  var t = document.createElement('div'); t.className='toast'; t.style.background=bg; t.textContent=msg;
  document.body.appendChild(t);
  setTimeout(function(){ t.style.opacity='0'; t.style.transition='opacity .3s'; }, 2200);
  setTimeout(function(){ t.remove(); }, 2700);
};
</script>
