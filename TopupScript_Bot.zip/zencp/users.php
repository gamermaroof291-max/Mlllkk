<?php
$pageTitle = 'Users';
require __DIR__ . '/common/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { header('Location: users.php'); exit; }
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    if ($action === 'toggle') {
        $st = $pdo->prepare("SELECT status FROM users WHERE id=?"); $st->execute([$id]);
        $cur = $st->fetchColumn();
        $new = $cur === 'active' ? 'suspended' : 'active';
        $pdo->prepare("UPDATE users SET status=? WHERE id=?")->execute([$new, $id]);
    } elseif ($action === 'adjust') {
        $amt = (float)($_POST['amount'] ?? 0);
        $note = trim((string)($_POST['note'] ?? 'Admin adjustment'));
        if ($amt != 0) {
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id=?")->execute([$amt, $id]);
            $pdo->prepare("INSERT INTO transactions (user_id, type, amount, note, ref_id) VALUES (?, 'admin', ?, ?, ?)")
                ->execute([$id, $amt, $note, 'ADJ-' . time()]);
        }
    } elseif ($action === 'reset_pw') {
        $newPw = trim((string)($_POST['new_pw'] ?? ''));
        if (strlen($newPw) >= 6) {
            $pdo->prepare("UPDATE users SET password=? WHERE id=?")
                ->execute([password_hash($newPw, PASSWORD_BCRYPT), $id]);
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
    }
    header('Location: users.php'); exit;
}

$q = trim($_GET['q'] ?? '');
$where = ''; $params = [];
if ($q !== '') {
    $where = "WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?";
    $params = ["%$q%","%$q%","%$q%"];
}
$st = $pdo->prepare("SELECT * FROM users $where ORDER BY id DESC LIMIT 200");
$st->execute($params); $users = $st->fetchAll();
?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-2xl font-extrabold">Users <span class="text-slate-500 text-base font-normal">(<?= count($users) ?>)</span></h1>
  <form method="get" class="flex gap-2">
    <input name="q" class="input" style="max-width:280px" placeholder="Search by name / phone / email" value="<?= e($q) ?>">
    <button class="btn btn-primary"><i class="fa-solid fa-search"></i></button>
  </form>
</div>

<div class="glass overflow-x-auto">
  <table class="w-full">
    <thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Balance</th><th>Status</th><th>Joined</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($users as $u): ?>
      <tr class="row-link">
        <td>
          <div class="flex items-center gap-2">
            <div class="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-xs"><?= e(strtoupper(substr($u['name'],0,1))) ?></div>
            <div><div class="font-semibold"><?= e($u['name']) ?></div><div class="text-[10px] text-slate-500">PIN: <?= e($u['support_pin']) ?></div></div>
          </div>
        </td>
        <td class="text-xs font-mono"><?= e($u['phone']) ?></td>
        <td class="text-xs"><?= e($u['email']) ?></td>
        <td class="font-bold text-emerald-500"><?= format_money($u['balance']) ?></td>
        <td><span class="pill <?= $u['status']==='active'?'bg-emerald-500':'bg-rose-500' ?> text-white"><?= ucfirst($u['status']) ?></span></td>
        <td class="text-xs text-slate-500"><?= time_ago($u['created_at']) ?></td>
        <td class="flex flex-wrap gap-1">
          <button onclick="adjust(<?= (int)$u['id'] ?>, '<?= e(addslashes($u['name'])) ?>')" class="btn btn-ghost" title="Adjust balance"><i class="fa-solid fa-coins"></i></button>
          <button onclick="resetPw(<?= (int)$u['id'] ?>)" class="btn btn-ghost" title="Reset password"><i class="fa-solid fa-key"></i></button>
          <form method="post" class="inline"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="btn btn-warn" title="Toggle status"><i class="fa-solid fa-power-off"></i></button></form>
          <form method="post" onsubmit="return confirmAction('Delete this user permanently?')" class="inline"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button></form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<form method="post" id="adjForm" class="hidden">
  <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="adjust">
  <input type="hidden" name="id" id="adjId">
  <input type="hidden" name="amount" id="adjAmt">
  <input type="hidden" name="note" id="adjNote">
</form>
<form method="post" id="pwForm" class="hidden">
  <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="reset_pw">
  <input type="hidden" name="id" id="pwId">
  <input type="hidden" name="new_pw" id="pwNew">
</form>

<script>
function adjust(id, name){
  var amt = prompt('Enter amount for '+name+' (positive to add, negative to deduct):');
  if (amt === null || amt === '') return;
  var note = prompt('Note (optional):', 'Admin adjustment') || 'Admin adjustment';
  document.getElementById('adjId').value = id;
  document.getElementById('adjAmt').value = amt;
  document.getElementById('adjNote').value = note;
  document.getElementById('adjForm').submit();
}
function resetPw(id){
  var pw = prompt('Enter new password (min 6 chars):');
  if (!pw || pw.length < 6) { alert('Password too short'); return; }
  document.getElementById('pwId').value = id;
  document.getElementById('pwNew').value = pw;
  document.getElementById('pwForm').submit();
}
</script>
<?php require __DIR__ . '/common/footer.php'; ?>
