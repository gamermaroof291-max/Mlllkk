<?php
$pageTitle = 'Sliders';
require __DIR__ . '/common/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { header('Location: sliders.php'); exit; }
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $img = $_POST['image_url'] ?? '';
        $link = trim((string)($_POST['link'] ?? ''));
        $sort = (int)($_POST['sort_order'] ?? 0);
        $stat = $_POST['status'] === 'inactive' ? 'inactive' : 'active';
        if (!empty($_FILES['image']['name'])) { $u = save_upload($_FILES['image'], 'sliders'); if ($u) $img = $u; }
        if ($id) {
            $pdo->prepare("UPDATE sliders SET link=?, sort_order=?, status=?, image=COALESCE(NULLIF(?,''),image) WHERE id=?")
                ->execute([$link, $sort, $stat, $img, $id]);
        } else {
            $pdo->prepare("INSERT INTO sliders (image, link, sort_order, status) VALUES (?,?,?,?)")
                ->execute([$img, $link, $sort, $stat]);
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM sliders WHERE id=?")->execute([(int)$_POST['id']]);
    }
    header('Location: sliders.php'); exit;
}
$rows = $pdo->query("SELECT * FROM sliders ORDER BY sort_order, id")->fetchAll();
$edit = null;
if (isset($_GET['edit'])) { $st = $pdo->prepare("SELECT * FROM sliders WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit = $st->fetch() ?: null; }
?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-2xl font-extrabold">Home Sliders</h1>
  <a href="?edit=new" class="btn btn-primary"><i class="fa-solid fa-plus"></i>Add</a>
</div>

<?php if ($edit !== null || ($_GET['edit'] ?? '') === 'new'): $e = $edit ?: []; ?>
<div class="glass p-5 mb-5">
  <h3 class="font-bold mb-3"><?= $edit ? 'Edit' : 'Add' ?> Slider</h3>
  <form method="post" enctype="multipart/form-data" class="grid md:grid-cols-2 gap-3">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)($e['id'] ?? 0) ?>">
    <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Image URL or upload</label>
      <input name="image_url" class="input mt-1" placeholder="https://..." value="<?= e($e['image'] ?? '') ?>">
      <input type="file" name="image" accept="image/*" class="mt-2 text-xs"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Link (optional)</label><input name="link" class="input mt-1" value="<?= e($e['link'] ?? '') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Sort</label><input name="sort_order" type="number" class="input mt-1" value="<?= (int)($e['sort_order'] ?? 0) ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Status</label>
      <select name="status" class="select mt-1"><option value="active" <?= ($e['status'] ?? 'active')==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= ($e['status'] ?? '')==='inactive'?'selected':'' ?>>Inactive</option></select></div>
    <div class="md:col-span-2 flex gap-2"><button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i>Save</button><a href="sliders.php" class="btn btn-ghost">Cancel</a></div>
  </form>
</div>
<?php endif; ?>

<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
  <?php foreach ($rows as $s): ?>
  <div class="glass overflow-hidden">
    <img src="<?= e($s['image']) ?>" class="w-full h-32 object-cover">
    <div class="p-3 flex items-center justify-between">
      <div>
        <span class="pill <?= $s['status']==='active'?'bg-emerald-500':'bg-rose-500' ?> text-white"><?= ucfirst($s['status']) ?></span>
        <span class="text-xs text-slate-500 ml-1">Sort: <?= (int)$s['sort_order'] ?></span>
      </div>
      <div class="flex gap-1">
        <a href="?edit=<?= (int)$s['id'] ?>" class="btn btn-ghost"><i class="fa-solid fa-pen"></i></a>
        <form method="post" onsubmit="return confirmAction('Delete?')">
          <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
          <button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
        </form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><div class="glass p-8 text-center text-slate-500 col-span-full">No sliders yet.</div><?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>
