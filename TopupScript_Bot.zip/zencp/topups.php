<?php
$pageTitle = 'Wallet Top-ups';
require __DIR__ . '/common/header.php';

$pdo = db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { http_response_code(403); echo json_encode(['success'=>false]); exit; }
    $id = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';
    $note = trim((string)($_POST['note'] ?? ''));

    $st = $pdo->prepare("SELECT * FROM wallet_topup WHERE id = ?");
    $st->execute([$id]);
    $t = $st->fetch();
    if (!$t || $t['status'] !== 'pending') { http_response_code(400); echo json_encode(['success'=>false,'message'=>'Already processed']); exit; }

    $pdo->beginTransaction();
    try {
        if ($action === 'approve') {
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")
                ->execute([$t['amount'], $t['user_id']]);
            $pdo->prepare("UPDATE wallet_topup SET status='approved', note=? WHERE id=?")
                ->execute([$note ?: null, $id]);
            $pdo->prepare("INSERT INTO transactions (user_id, type, amount, note, ref_id) VALUES (?, 'topup', ?, ?, ?)")
                ->execute([$t['user_id'], $t['amount'], 'Wallet top-up approved', 'TOPUP-'.$id]);
        } elseif ($action === 'reject') {
            $pdo->prepare("UPDATE wallet_topup SET status='rejected', note=? WHERE id=?")
                ->execute([$note ?: 'Rejected', $id]);
        } else { throw new Exception('Invalid action'); }
        $pdo->commit();
        echo json_encode(['success'=>true]);
    } catch (Throwable $e) {
        $pdo->rollBack();
        http_response_code(500); echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
    }
    exit;
}

$status = $_GET['status'] ?? 'all';
$where = ''; $p = [];
if (in_array($status, ['pending','approved','rejected'], true)) { $where = "WHERE w.status=?"; $p[]=$status; }
$sql = "SELECT w.*, u.name AS user_name, u.phone AS user_phone, pm.name AS method
        FROM wallet_topup w JOIN users u ON u.id=w.user_id LEFT JOIN payment_methods pm ON pm.id=w.method_id
        $where ORDER BY w.id DESC LIMIT 200";
$st = $pdo->prepare($sql); $st->execute($p); $rows = $st->fetchAll();
?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-2xl font-extrabold">Wallet Top-ups <span class="text-slate-500 text-base font-normal">(<?= count($rows) ?>)</span></h1>
  <div class="flex gap-2">
    <?php foreach (['all','pending','approved','rejected'] as $s): ?>
      <a href="?status=<?= $s ?>" class="btn <?= $status===$s?'btn-primary':'btn-ghost' ?>"><?= ucfirst($s) ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="glass overflow-x-auto">
  <table class="w-full">
    <thead><tr><th>User</th><th>Amount</th><th>Method</th><th>Sender</th><th>TxnID</th><th>Status</th><th>Date</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r):
        $col = ['pending'=>'bg-amber-500','approved'=>'bg-emerald-500','rejected'=>'bg-rose-500'][$r['status']] ?? 'bg-slate-500';
      ?>
      <tr class="row-link">
        <td><div class="font-semibold"><?= e($r['user_name']) ?></div><div class="text-xs text-slate-500"><?= e($r['user_phone']) ?></div></td>
        <td class="font-bold text-primary"><?= format_money($r['amount']) ?></td>
        <td><?= e($r['method'] ?? '—') ?></td>
        <td class="text-xs font-mono"><?= e($r['sender_number']) ?></td>
        <td class="text-xs font-mono"><?= e($r['trx_id']) ?></td>
        <td><span class="pill <?= $col ?> text-white"><?= ucfirst($r['status']) ?></span></td>
        <td class="text-xs text-slate-500"><?= time_ago($r['created_at']) ?></td>
        <td>
          <?php if ($r['status'] === 'pending'): ?>
            <div class="flex gap-1">
              <button onclick="act(<?= (int)$r['id'] ?>, 'approve')" class="btn btn-success" title="Approve"><i class="fa-solid fa-check"></i></button>
              <button onclick="act(<?= (int)$r['id'] ?>, 'reject')" class="btn btn-danger" title="Reject"><i class="fa-solid fa-xmark"></i></button>
            </div>
          <?php else: ?>
            <span class="text-xs text-slate-500"><?= e($r['note'] ?: '—') ?></span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-slate-500 py-8">No top-up requests.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<script>
async function act(id, a){
  var note = prompt(a==='approve'?'Optional note to user:':'Reason for rejection:');
  if (note===null) return;
  var fd = new FormData();
  fd.append('id', id); fd.append('action', a); fd.append('note', note); fd.append('_csrf','<?= e(csrf_token()) ?>');
  var r = await fetch('topups.php', { method:'POST', body: fd });
  var j = await r.json();
  if (j.success) { window.czToast('Done', 'success'); setTimeout(()=>location.reload(), 500); }
  else window.czToast(j.message || 'Error', 'error');
}
</script>
<?php require __DIR__ . '/common/footer.php'; ?>
