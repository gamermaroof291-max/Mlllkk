<?php
require_once __DIR__ . '/auth.php';
$pageTitle = ($pageTitle ?? 'Admin') . ' — ' . setting('site_name', 'Code Zen');
$cur = basename($_SERVER['SCRIPT_NAME'] ?? '');
$cnt = function($t, $where = '', $params = []) {
    try {
        $sql = "SELECT COUNT(*) FROM $t" . ($where ? " WHERE $where" : '');
        $st = db()->prepare($sql); $st->execute($params);
        return (int)$st->fetchColumn();
    } catch (Throwable $e) { return 0; }
};
$pendingOrders = $cnt('orders', "status = 'pending'");
$pendingTopups = $cnt('wallet_topup', "status = 'pending'");
?>
<!doctype html>
<html lang="en" class="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script>tailwind.config={darkMode:'class',theme:{extend:{colors:{primary:'<?= e(setting('primary_color','#1A8FBD')) ?>',accent:'<?= e(setting('accent_color','#F97316')) ?>',gold:'<?= e(setting('gold_color','#F59E0B')) ?>'},fontFamily:{sans:['Inter','system-ui']}}}};</script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root { --c-primary:<?= e(setting('primary_color','#1A8FBD')) ?>; --c-accent:<?= e(setting('accent_color','#F97316')) ?>; }
html,body { font-family:'Inter',sans-serif; }
body { background: radial-gradient(1000px 600px at 10% 0%, rgba(26,143,189,.18), transparent 60%), radial-gradient(800px 600px at 100% 100%, rgba(249,115,22,.12), transparent 60%), #0A0F1E; color: #E2E8F0; min-height:100vh; }
.glass { background: rgba(255,255,255,.04); backdrop-filter: blur(18px); border: 1px solid rgba(255,255,255,.08); border-radius: 16px; }
.btn { display:inline-flex; align-items:center; gap:.4rem; padding:.6rem 1rem; border-radius:10px; font-weight:600; font-size:13px; transition:all .2s; border:none; cursor:pointer; }
.btn-primary { background: linear-gradient(135deg, var(--c-primary), var(--c-accent)); color:#fff; box-shadow:0 4px 14px rgba(26,143,189,.35); }
.btn-primary:hover { transform: translateY(-1px); filter:brightness(1.08); }
.btn-ghost { background: rgba(255,255,255,.06); color:#fff; }
.btn-ghost:hover { background: rgba(255,255,255,.1); }
.btn-danger { background: #ef4444; color: #fff; }
.btn-success { background: #10b981; color:#fff; }
.btn-warn { background: #f59e0b; color:#fff; }
.input, .select, textarea { width:100%; padding:.65rem .9rem; border-radius:10px; background: rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); color:#fff; font-size:13px; transition:border-color .15s,box-shadow .15s; }
.input:focus, .select:focus, textarea:focus { outline:none; border-color: var(--c-primary); box-shadow:0 0 0 3px rgba(26,143,189,.2); }
.pill { padding:3px 10px; border-radius:999px; font-size:11px; font-weight:700; display:inline-flex; align-items:center; gap:4px; }
.row-link { transition: background .15s; }
.row-link:hover { background: rgba(255,255,255,.04); }
table { border-collapse: separate; border-spacing: 0; width:100%; }
th { background: rgba(255,255,255,.04); padding:.75rem .9rem; font-size:11px; text-transform:uppercase; letter-spacing:.04em; color:#94a3b8; text-align:left; font-weight:700; }
td { padding:.8rem .9rem; border-top: 1px solid rgba(255,255,255,.05); font-size:13px; vertical-align: middle; }
.toast { position:fixed; bottom:30px; right:30px; padding:.85rem 1.3rem; border-radius:12px; color:#fff; font-weight:500; box-shadow:0 8px 28px rgba(0,0,0,.4); z-index:80; }
::-webkit-scrollbar{width:8px;height:8px;} ::-webkit-scrollbar-thumb{background:rgba(26,143,189,.45);border-radius:8px;}
.sidebar-link { display:flex; align-items:center; gap:.7rem; padding:.6rem .9rem; border-radius:10px; font-size:13px; font-weight:600; color:#cbd5e1; transition: all .15s; }
.sidebar-link:hover { background: rgba(255,255,255,.06); color:#fff; }
.sidebar-link.active { background: linear-gradient(90deg, rgba(26,143,189,.3), rgba(249,115,22,.15)); color:#fff; box-shadow: inset 3px 0 0 var(--c-primary); }
.stat-card { padding:1.1rem; border-radius:16px; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); position:relative; overflow:hidden; }
.stat-card::before { content:""; position:absolute; top:-50%; right:-30%; width:160px; height:160px; border-radius:50%; background:radial-gradient(circle, rgba(26,143,189,.25), transparent 70%); }
@keyframes fadeUp { from{opacity:0;transform:translateY(10px);} to{opacity:1;transform:none;} }
.fade-in { animation: fadeUp .35s ease both; }
</style>
</head>
<body>
<div class="flex min-h-screen">
  <aside class="w-60 shrink-0 hidden md:flex flex-col p-3 gap-1 border-r border-white/5 bg-black/30">
    <a href="<?= e(site_url('zencp/index.php')) ?>" class="flex items-center gap-2 px-2 py-3 mb-2">
      <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-extrabold">CZ</div>
      <div>
        <div class="font-extrabold text-sm leading-none">ZenCP</div>
        <div class="text-[10px] text-slate-400 mt-0.5">Admin Panel</div>
      </div>
    </a>

    <?php
    $sections = [
      'Operations' => [
        ['index.php',         'fa-gauge-high',   'Dashboard'],
        ['orders.php',        'fa-bag-shopping', 'Orders', $pendingOrders],
        ['topups.php',        'fa-wallet',       'Wallet Top-ups', $pendingTopups],
      ],
      'Catalog' => [
        ['games.php',         'fa-gamepad',      'Games / Categories'],
        ['products.php',      'fa-box',          'Products / Packs'],
        ['redeem_codes.php',  'fa-key',          'Redeem Codes'],
      ],
      'Site' => [
        ['sliders.php',       'fa-images',       'Banner Sliders'],
        ['payments.php',      'fa-credit-card',  'Payment Methods'],
        ['helplines.php',     'fa-headset',      'Helplines (Footer)'],
        ['app.php',           'fa-mobile-screen','App Download'],
      ],
      'People' => [
        ['users.php',         'fa-users',        'Users'],
      ],
      'Settings' => [
        ['settings.php',      'fa-gear',         'Settings'],
      ],
    ];
    foreach ($sections as $secName => $links): ?>
      <div class="text-[10px] uppercase font-bold text-slate-500 mt-3 mb-1 px-2"><?= e($secName) ?></div>
      <?php foreach ($links as $l):
        $active = $cur === $l[0]; ?>
        <a href="<?= e(site_url('zencp/' . $l[0])) ?>" class="sidebar-link <?= $active ? 'active' : '' ?>">
          <i class="fa-solid <?= $l[1] ?> w-5 text-center"></i>
          <span class="flex-1"><?= e($l[2]) ?></span>
          <?php if (!empty($l[3])): ?><span class="pill bg-rose-500 text-white"><?= (int)$l[3] ?></span><?php endif; ?>
        </a>
      <?php endforeach;
    endforeach; ?>

    <div class="mt-auto p-3 border-t border-white/5">
      <div class="text-xs text-slate-400 mb-1">Logged in as</div>
      <div class="font-bold text-sm"><?= e($ADMIN['username']) ?></div>
      <a href="<?= e(site_url('zencp/logout.php')) ?>" class="text-rose-400 text-xs mt-2 inline-block"><i class="fa-solid fa-right-from-bracket mr-1"></i>Logout</a>
      <a href="<?= e(site_url('index.php')) ?>" target="_blank" class="text-slate-400 text-xs mt-2 inline-block ml-3"><i class="fa-solid fa-arrow-up-right-from-square mr-1"></i>View site</a>
    </div>
  </aside>

  <div class="flex-1 min-w-0">
    <header class="md:hidden flex items-center justify-between p-3 bg-black/40 border-b border-white/5">
      <a href="<?= e(site_url('zencp/index.php')) ?>" class="flex items-center gap-2">
        <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-extrabold text-sm">CZ</div>
        <span class="font-bold">ZenCP</span>
      </a>
      <button onclick="document.getElementById('mobMenu').classList.toggle('hidden')" class="p-2"><i class="fa-solid fa-bars"></i></button>
    </header>

    <div id="mobMenu" class="md:hidden hidden p-3 bg-black/40 border-b border-white/5 grid grid-cols-2 gap-2">
      <?php foreach ($sections as $secName => $links): foreach ($links as $l): ?>
        <a href="<?= e(site_url('zencp/' . $l[0])) ?>" class="sidebar-link"><i class="fa-solid <?= $l[1] ?>"></i> <?= e($l[2]) ?></a>
      <?php endforeach; endforeach; ?>
      <a href="<?= e(site_url('zencp/logout.php')) ?>" class="sidebar-link text-rose-400"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </div>

    <main class="p-4 md:p-6 fade-in">
<script>
window.czToast = function(msg, kind){
  var bg = { success:'#10b981', error:'#ef4444', warn:'#f59e0b', info:'#1A8FBD' }[kind||'info'];
  var t = document.createElement('div'); t.className='toast'; t.style.background=bg; t.textContent=msg;
  document.body.appendChild(t); setTimeout(()=>t.style.opacity='0', 2200); setTimeout(()=>t.remove(), 2700);
};
function confirmAction(msg){ return confirm(msg || 'Are you sure?'); }
</script>
