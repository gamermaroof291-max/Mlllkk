<?php
require_once __DIR__ . '/../../common/config.php';
require_admin();
$ADMIN = admin_user();
