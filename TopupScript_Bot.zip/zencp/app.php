<?php
$pageTitle = 'App Download';
require __DIR__ . '/common/header.php';
$pdo = db();
$msg = ''; $err = '';

$apkDir = realpath(__DIR__ . '/..') . '/uploads/apk';
if (!is_dir($apkDir)) @mkdir($apkDir, 0775, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { $err = 'Bad CSRF.'; }
    else {
        $action = $_POST['action'] ?? '';
        if ($action === 'upload') {
            $version   = sanitize($_POST['version'] ?? '');
            $changelog = trim((string)($_POST['changelog'] ?? ''));
            $status    = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
            if (!$version) $err = 'Version is required.';
            elseif (empty($_FILES['apk']['tmp_name'])) $err = 'Choose an APK file.';
            elseif ($_FILES['apk']['error'] !== UPLOAD_ERR_OK) $err = 'Upload failed (code '.(int)$_FILES['apk']['error'].'). Increase upload_max_filesize in php.ini.';
            else {
                $orig = $_FILES['apk']['name'];
                $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
                if ($ext !== 'apk') { $err = 'Only .apk files are allowed.'; }
                else {
                    $safe = 'app-v' . preg_replace('/[^A-Za-z0-9._-]/','_', $version) . '-' . time() . '.apk';
                    $dest = $apkDir . '/' . $safe;
                    if (!move_uploaded_file($_FILES['apk']['tmp_name'], $dest)) $err = 'Could not save uploaded file.';
                    else {
                        $rel  = 'uploads/apk/' . $safe;
                        $size = filesize($dest);
                        $pdo->prepare("INSERT INTO app_versions (version, file_path, file_size, changelog, status) VALUES (?,?,?,?,?)")
                            ->execute([$version, $rel, $size, $changelog, $status]);
                        $msg = 'APK uploaded successfully (v'.$version.', '.number_format($size/1048576,1).' MB).';
                    }
                }
            }
        } elseif ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            $st = $pdo->prepare("SELECT status, file_path FROM app_versions WHERE id=?"); $st->execute([$id]); $v = $st->fetch();
            if ($v) {
                $new = $v['status'] === 'active' ? 'inactive' : 'active';
                $pdo->prepare("UPDATE app_versions SET status=? WHERE id=?")->execute([$new, $id]);
                $msg = 'Status changed to '.$new.'.';
            }
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $st = $pdo->prepare("SELECT file_path FROM app_versions WHERE id=?"); $st->execute([$id]); $v = $st->fetch();
            if ($v) {
                $f = realpath(__DIR__ . '/..') . '/' . ltrim($v['file_path'],'/');
                if (file_exists($f)) @unlink($f);
                $pdo->prepare("DELETE FROM app_versions WHERE id=?")->execute([$id]);
                $msg = 'Version deleted.';
            }
        } elseif ($action === 'meta') {
            $keys = ['app_show','app_name','app_subtitle','app_features'];
            foreach ($keys as $k) if (array_key_exists($k, $_POST)) set_setting($k, (string)$_POST[$k]);
            if (!isset($_POST['app_show'])) set_setting('app_show', '0');
            $msg = 'App settings updated.';
        }
    }
}

$versions = $pdo->query("SELECT * FROM app_versions ORDER BY id DESC")->fetchAll();
$totalDownloads = (int)$pdo->query("SELECT COALESCE(SUM(downloads),0) FROM app_versions")->fetchColumn();

$phpMax = ini_get('upload_max_filesize');
$postMax = ini_get('post_max_size');
?>
<div class="flex items-center justify-between mb-4">
  <div>
    <h1 class="text-2xl font-extrabold">App Download Manager</h1>
    <p class="text-sm text-slate-400 mt-1">Upload your official Android APK and let users install it from <code class="bg-white/5 px-1.5 py-0.5 rounded text-primary">/app.php</code></p>
  </div>
  <a href="<?= e(site_url('app.php')) ?>" target="_blank" class="btn btn-ghost"><i class="fa-solid fa-arrow-up-right-from-square"></i>View Public Page</a>
</div>

<?php if ($msg): ?><div class="bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-xl p-3 mb-3 text-sm"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="bg-rose-500/15 border border-rose-500/30 text-rose-400 rounded-xl p-3 mb-3 text-sm"><?= e($err) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-3 gap-3 mb-5">
  <div class="stat-card"><div class="text-xs text-slate-400 mb-1 relative z-10">Active version</div>
    <div class="text-2xl font-extrabold relative z-10">v<?= e($versions[0]['version'] ?? '—') ?></div></div>
  <div class="stat-card"><div class="text-xs text-slate-400 mb-1 relative z-10">Total versions</div>
    <div class="text-2xl font-extrabold relative z-10"><?= count($versions) ?></div></div>
  <div class="stat-card"><div class="text-xs text-slate-400 mb-1 relative z-10">Total downloads</div>
    <div class="text-2xl font-extrabold relative z-10"><?= number_format($totalDownloads) ?></div></div>
</div>

<div class="grid lg:grid-cols-2 gap-4">
  <div class="glass p-5">
    <h3 class="font-bold text-base mb-3"><i class="fa-solid fa-cloud-arrow-up text-primary mr-1"></i>Upload New APK</h3>
    <form method="post" enctype="multipart/form-data" class="space-y-3">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="upload">
      <div class="grid grid-cols-2 gap-2">
        <div><label class="text-xs uppercase font-semibold text-slate-400">Version</label>
          <input name="version" class="input mt-1" placeholder="1.0.0" required></div>
        <div><label class="text-xs uppercase font-semibold text-slate-400">Status</label>
          <select name="status" class="select mt-1">
            <option value="active">Active (visible)</option>
            <option value="inactive">Inactive (hidden)</option>
          </select></div>
      </div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Changelog (optional)</label>
        <textarea name="changelog" rows="3" placeholder="• Faster checkout&#10;• Bug fixes"></textarea></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">APK File</label>
        <input name="apk" type="file" accept=".apk,application/vnd.android.package-archive" class="mt-1 text-xs w-full" required>
        <div class="text-[11px] text-slate-500 mt-1">PHP upload limit: <b><?= e($phpMax) ?></b> / post: <b><?= e($postMax) ?></b>. If your APK is larger, raise <code>upload_max_filesize</code> & <code>post_max_size</code> in php.ini.</div></div>
      <button class="btn btn-primary w-full justify-center"><i class="fa-solid fa-upload"></i>Upload APK</button>
    </form>
  </div>

  <div class="glass p-5">
    <h3 class="font-bold text-base mb-3"><i class="fa-solid fa-sliders text-accent mr-1"></i>App Page Settings</h3>
    <form method="post" class="space-y-3">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="meta">
      <label class="flex items-center gap-2"><input type="checkbox" name="app_show" value="1" <?= setting('app_show','1')==='1'?'checked':'' ?>> Show "Get App" banner on home page</label>
      <div><label class="text-xs uppercase font-semibold text-slate-400">App display name</label>
        <input name="app_name" class="input mt-1" value="<?= e(setting('app_name','')) ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Subtitle</label>
        <input name="app_subtitle" class="input mt-1" value="<?= e(setting('app_subtitle','')) ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Features (one per line)</label>
        <textarea name="app_features" rows="5"><?= e(setting('app_features','')) ?></textarea></div>
      <button class="btn btn-primary w-full justify-center"><i class="fa-solid fa-floppy-disk"></i>Save</button>
    </form>
  </div>
</div>

<div class="glass mt-5 overflow-x-auto">
  <table>
    <thead><tr><th>Version</th><th>Size</th><th>Changelog</th><th>Downloads</th><th>Status</th><th>Uploaded</th><th></th></tr></thead>
    <tbody>
      <?php if (!$versions): ?>
        <tr><td colspan="7" class="text-center text-slate-500 py-6">No APK uploaded yet. Use the form above to upload your first version.</td></tr>
      <?php else: foreach ($versions as $v): ?>
        <tr class="row-link">
          <td class="font-bold">v<?= e($v['version']) ?></td>
          <td><?= number_format(($v['file_size'] ?: 0)/1048576,2) ?> MB</td>
          <td class="max-w-xs truncate text-slate-400 text-xs"><?= e($v['changelog'] ?: '—') ?></td>
          <td><?= number_format((int)$v['downloads']) ?></td>
          <td><span class="pill <?= $v['status']==='active'?'bg-emerald-500':'bg-slate-500' ?> text-white"><?= ucfirst(e($v['status'])) ?></span></td>
          <td class="text-xs text-slate-400"><?= e(date('M d, Y', strtotime($v['created_at']))) ?></td>
          <td class="flex gap-1">
            <a href="<?= e(site_url($v['file_path'])) ?>" target="_blank" class="btn btn-ghost" title="Direct download"><i class="fa-solid fa-download"></i></a>
            <form method="post" class="inline">
              <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= (int)$v['id'] ?>">
              <button class="btn btn-warn" title="Toggle active"><i class="fa-solid fa-power-off"></i></button>
            </form>
            <form method="post" class="inline" onsubmit="return confirmAction('Delete this APK file forever?')">
              <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$v['id'] ?>">
              <button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/common/footer.php'; ?>
