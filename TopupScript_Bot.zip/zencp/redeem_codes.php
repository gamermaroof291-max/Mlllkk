<?php
$pageTitle = 'Redeem Codes';
require __DIR__ . '/common/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { header('Location: redeem_codes.php'); exit; }
    $action = $_POST['action'] ?? '';
    if ($action === 'add_bulk') {
        $cat = (int)($_POST['cat_id'] ?? 0);
        $prod = (int)($_POST['product_id'] ?? 0);
        $codes = preg_split('/[\r\n,]+/', (string)($_POST['codes'] ?? ''));
        $codes = array_filter(array_map('trim', $codes));
        $ins = 0;
        foreach ($codes as $c) {
            try {
                $pdo->prepare("INSERT INTO redeem_codes (cat_id, product_id, code, status) VALUES (?,?,?, 'unused')")
                    ->execute([$cat, $prod, $c]);
                $ins++;
            } catch (Throwable $e) {}
        }
        $_SESSION['flash'] = "Inserted $ins codes.";
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM redeem_codes WHERE id=? AND status='unused'")->execute([(int)$_POST['id']]);
    }
    header('Location: redeem_codes.php'); exit;
}

$cats = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();
$prodAll = $pdo->query("SELECT id, cat_id, name FROM products ORDER BY cat_id, name")->fetchAll();

$status = $_GET['status'] ?? 'all';
$where = ''; $p = [];
if (in_array($status, ['unused','used'], true)) { $where = "WHERE rc.status=?"; $p[]=$status; }
$sql = "SELECT rc.*, c.name AS cat_name, pr.name AS prod_name FROM redeem_codes rc
  JOIN categories c ON c.id = rc.cat_id JOIN products pr ON pr.id = rc.product_id
  $where ORDER BY rc.id DESC LIMIT 300";
$st = $pdo->prepare($sql); $st->execute($p); $codes = $st->fetchAll();
?>
<h1 class="text-2xl font-extrabold mb-4">Redeem Codes</h1>

<?php if (!empty($_SESSION['flash'])): ?>
  <div class="bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-xl p-3 mb-3 text-sm"><?= e($_SESSION['flash']) ?></div>
  <?php unset($_SESSION['flash']); ?>
<?php endif; ?>

<div class="grid lg:grid-cols-3 gap-4">
  <div class="glass p-5 lg:col-span-1">
    <h3 class="font-bold mb-3"><i class="fa-solid fa-plus text-primary mr-1"></i>Bulk Add Codes</h3>
    <form method="post" class="space-y-3">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <input type="hidden" name="action" value="add_bulk">
      <div><label class="text-xs uppercase font-semibold text-slate-400">Game</label>
        <select name="cat_id" id="catSel" class="select mt-1" required>
          <option value="">— select —</option>
          <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Product</label>
        <select name="product_id" id="prodSel" class="select mt-1" required><option value="">— select game first —</option></select></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Codes (one per line)</label>
        <textarea name="codes" rows="6" class="mt-1" placeholder="ABCD-1234-EFGH&#10;XYZW-5678-IJKL"></textarea></div>
      <button class="btn btn-primary w-full justify-center"><i class="fa-solid fa-upload"></i>Upload Codes</button>
    </form>
  </div>

  <div class="glass p-5 lg:col-span-2">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-bold"><i class="fa-solid fa-list text-primary mr-1"></i>Code Inventory</h3>
      <div class="flex gap-1">
        <?php foreach (['all','unused','used'] as $s): ?>
          <a href="?status=<?= $s ?>" class="btn <?= $status===$s?'btn-primary':'btn-ghost' ?>"><?= ucfirst($s) ?></a>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full">
        <thead><tr><th>Code</th><th>Game</th><th>Product</th><th>Status</th><th>Date</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($codes as $r): ?>
          <tr class="row-link">
            <td class="font-mono text-xs"><?= e($r['code']) ?></td>
            <td><?= e($r['cat_name']) ?></td>
            <td class="text-slate-400"><?= e($r['prod_name']) ?></td>
            <td><span class="pill <?= $r['status']==='unused'?'bg-emerald-500':'bg-slate-500' ?> text-white"><?= ucfirst($r['status']) ?></span></td>
            <td class="text-xs text-slate-500"><?= time_ago($r['created_at']) ?></td>
            <td>
              <?php if ($r['status'] === 'unused'): ?>
              <form method="post" onsubmit="return confirmAction('Delete this code?')">
                <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
              </form>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (!$codes): ?><tr><td colspan="6" class="text-center text-slate-500 py-8">No codes.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
var ALL_PRODS = <?= json_encode($prodAll) ?>;
document.getElementById('catSel').addEventListener('change', function(){
  var cat = parseInt(this.value);
  var sel = document.getElementById('prodSel');
  sel.innerHTML = '<option value="">— select —</option>';
  ALL_PRODS.filter(p=>p.cat_id==cat).forEach(p=>{
    var o = document.createElement('option'); o.value = p.id; o.textContent = p.name; sel.appendChild(o);
  });
});
</script>
<?php require __DIR__ . '/common/footer.php'; ?>
