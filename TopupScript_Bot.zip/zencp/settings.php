<?php
$pageTitle = 'Settings';
require __DIR__ . '/common/header.php';
$msg = '';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { $msg = 'Bad CSRF.'; }
    else {
        // Logo upload
        if (!empty($_FILES['logo_file']['name']) && $_FILES['logo_file']['error'] === UPLOAD_ERR_OK) {
            $up = save_upload($_FILES['logo_file'], 'logo');
            if ($up) set_setting('logo_image', $up);
        }
        if (!empty($_POST['clear_logo'])) set_setting('logo_image', '');

        $keys = [
          'site_name','site_title','site_description','logo_text','logo_tag',
          'currency_name','currency_symbol','currency_code',
          'min_addmoney','max_addmoney','marquee_text','fab_link','fab_icon','fab_label',
          'whatsapp_url','telegram_url','facebook_url','youtube_url','instagram_url',
          'support_phone','support_email','addmoney_video','addmoney_note',
          'primary_color','accent_color','gold_color','navy_color','theme_default',
          'home_warning_title','home_warning_text','footer_about','footer_copyright','rules_text',
          'app_show','app_name','app_subtitle','app_features',
        ];
        foreach ($keys as $k) {
            if (array_key_exists($k, $_POST)) set_setting($k, (string)$_POST[$k]);
        }
        // toggles
        if (!isset($_POST['marquee_enabled']))   set_setting('marquee_enabled', '0'); else set_setting('marquee_enabled', '1');
        if (!isset($_POST['fab_label_show']))    set_setting('fab_label_show', '0');  else set_setting('fab_label_show', '1');
        if (!isset($_POST['app_show']))          set_setting('app_show', '0');         else set_setting('app_show', '1');

        if (!empty($_POST['admin_pw'])) {
            $newPw = $_POST['admin_pw'];
            if (strlen($newPw) >= 6) {
                $pdo->prepare("UPDATE admin SET password=? WHERE id=?")
                    ->execute([password_hash($newPw, PASSWORD_BCRYPT), $ADMIN['id']]);
            }
        }
        $msg = 'Settings updated successfully.';
    }
}
$g = function($k, $d='') { return e(setting($k, $d)); };
?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-2xl font-extrabold">Site Settings</h1>
  <div class="flex gap-2">
    <a href="<?= e(site_url('index.php')) ?>" target="_blank" class="btn btn-ghost"><i class="fa-solid fa-eye"></i>Preview Site</a>
  </div>
</div>

<?php if ($msg): ?><div class="bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-xl p-3 mb-3 text-sm"><?= e($msg) ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="space-y-5">
  <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">

  <div class="glass p-5">
    <h3 class="font-bold mb-3"><i class="fa-solid fa-globe text-primary mr-1"></i>Site Identity</h3>
    <div class="grid md:grid-cols-2 gap-3">
      <div><label class="text-xs uppercase font-semibold text-slate-400">Site name</label><input name="site_name" class="input mt-1" value="<?= $g('site_name') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Browser tab title</label><input name="site_title" class="input mt-1" value="<?= $g('site_title') ?>"></div>
      <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Description (SEO)</label><textarea name="site_description" rows="2"><?= $g('site_description') ?></textarea></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Logo text (header)</label><input name="logo_text" class="input mt-1" value="<?= $g('logo_text') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Logo tagline</label><input name="logo_tag" class="input mt-1" value="<?= $g('logo_tag') ?>"></div>
      <div class="md:col-span-2">
        <label class="text-xs uppercase font-semibold text-slate-400">Logo image (overrides text logo)</label>
        <?php if (setting('logo_image')): ?>
          <div class="flex items-center gap-3 mt-1 mb-2 p-2 bg-white/5 rounded-lg">
            <img src="<?= e(site_url(setting('logo_image'))) ?>" class="h-10">
            <label class="text-xs text-rose-400"><input type="checkbox" name="clear_logo" value="1"> Remove current logo</label>
          </div>
        <?php endif; ?>
        <input name="logo_file" type="file" accept="image/*" class="text-xs">
      </div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Default theme</label>
        <select name="theme_default" class="select mt-1">
          <?php foreach (['light','dark','auto'] as $v): ?><option value="<?= $v ?>" <?= setting('theme_default')==$v?'selected':'' ?>><?= ucfirst($v) ?></option><?php endforeach; ?>
        </select></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Support phone</label><input name="support_phone" class="input mt-1" value="<?= $g('support_phone') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Support email</label><input name="support_email" type="email" class="input mt-1" value="<?= $g('support_email') ?>"></div>
    </div>
  </div>

  <div class="glass p-5">
    <h3 class="font-bold mb-3"><i class="fa-solid fa-coins text-amber-500 mr-1"></i>Currency &amp; Wallet</h3>
    <div class="grid md:grid-cols-3 gap-3">
      <div><label class="text-xs uppercase font-semibold text-slate-400">Currency name</label><input name="currency_name" class="input mt-1" value="<?= $g('currency_name') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Symbol</label><input name="currency_symbol" class="input mt-1" value="<?= $g('currency_symbol') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Code</label><input name="currency_code" class="input mt-1" value="<?= $g('currency_code') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Min add money</label><input name="min_addmoney" type="number" class="input mt-1" value="<?= $g('min_addmoney') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Max add money</label><input name="max_addmoney" type="number" class="input mt-1" value="<?= $g('max_addmoney') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Add Money YouTube embed URL</label><input name="addmoney_video" class="input mt-1" value="<?= $g('addmoney_video') ?>"></div>
      <div class="md:col-span-3"><label class="text-xs uppercase font-semibold text-slate-400">Add Money page note</label><textarea name="addmoney_note" rows="2"><?= $g('addmoney_note') ?></textarea></div>
    </div>
  </div>

  <div class="glass p-5">
    <h3 class="font-bold mb-3"><i class="fa-solid fa-bullhorn text-pink-500 mr-1"></i>Marquee &amp; Floating Help Button</h3>
    <div class="grid md:grid-cols-2 gap-3">
      <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Marquee text (top scrolling line)</label><input name="marquee_text" class="input mt-1" value="<?= $g('marquee_text') ?>"></div>
      <div><label><input type="checkbox" name="marquee_enabled" value="1" <?= setting('marquee_enabled','1')==='1'?'checked':'' ?>> Enable marquee</label></div>
      <div></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">FAB link</label><input name="fab_link" class="input mt-1" value="<?= $g('fab_link') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">FAB icon class (Font Awesome)</label><input name="fab_icon" class="input mt-1" value="<?= $g('fab_icon') ?>" placeholder="fa-phone / fa-headset"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">FAB label text (red pill)</label><input name="fab_label" class="input mt-1" value="<?= $g('fab_label') ?>"></div>
      <div class="flex items-end"><label><input type="checkbox" name="fab_label_show" value="1" <?= setting('fab_label_show','1')==='1'?'checked':'' ?>> Show FAB label pill</label></div>
    </div>
  </div>

  <div class="glass p-5">
    <h3 class="font-bold mb-3"><i class="fa-solid fa-share-nodes text-sky-500 mr-1"></i>Social &amp; Footer</h3>
    <div class="grid md:grid-cols-2 gap-3">
      <div><label class="text-xs uppercase font-semibold text-slate-400"><i class="fa-brands fa-whatsapp"></i> WhatsApp URL</label><input name="whatsapp_url" class="input mt-1" value="<?= $g('whatsapp_url') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400"><i class="fa-brands fa-telegram"></i> Telegram URL</label><input name="telegram_url" class="input mt-1" value="<?= $g('telegram_url') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400"><i class="fa-brands fa-facebook"></i> Facebook URL</label><input name="facebook_url" class="input mt-1" value="<?= $g('facebook_url') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400"><i class="fa-brands fa-instagram"></i> Instagram URL</label><input name="instagram_url" class="input mt-1" value="<?= $g('instagram_url') ?>"></div>
      <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400"><i class="fa-brands fa-youtube"></i> YouTube URL</label><input name="youtube_url" class="input mt-1" value="<?= $g('youtube_url') ?>"></div>
      <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Footer about text</label><textarea name="footer_about" rows="2"><?= $g('footer_about') ?></textarea></div>
      <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Footer copyright</label><input name="footer_copyright" class="input mt-1" value="<?= $g('footer_copyright') ?>"></div>
    </div>
    <p class="text-xs text-slate-500 mt-3">Manage the SUPPORT CENTER cards on <a href="helplines.php" class="text-primary font-bold">Helplines page</a>.</p>
  </div>

  <div class="glass p-5">
    <h3 class="font-bold mb-3"><i class="fa-solid fa-triangle-exclamation text-amber-500 mr-1"></i>Home Warning &amp; Rules</h3>
    <div class="grid md:grid-cols-2 gap-3">
      <div><label class="text-xs uppercase font-semibold text-slate-400">Warning title</label><input name="home_warning_title" class="input mt-1" value="<?= $g('home_warning_title') ?>"></div>
      <div></div>
      <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Warning text (home page)</label><textarea name="home_warning_text" rows="3"><?= $g('home_warning_text') ?></textarea></div>
      <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Default rules text (used on game pages without custom rules)</label><textarea name="rules_text" rows="5"><?= $g('rules_text') ?></textarea></div>
    </div>
  </div>

  <div class="glass p-5">
    <h3 class="font-bold mb-3"><i class="fa-brands fa-android text-emerald-500 mr-1"></i>Android App</h3>
    <p class="text-xs text-slate-400 mb-3">Upload APK files on the <a href="app.php" class="text-primary font-bold">App Download page</a>. Settings below control the home banner &amp; landing page.</p>
    <div class="grid md:grid-cols-2 gap-3">
      <div class="md:col-span-2"><label><input type="checkbox" name="app_show" value="1" <?= setting('app_show','1')==='1'?'checked':'' ?>> Show "Get App" banner on home page</label></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">App name</label><input name="app_name" class="input mt-1" value="<?= $g('app_name') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Subtitle</label><input name="app_subtitle" class="input mt-1" value="<?= $g('app_subtitle') ?>"></div>
      <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Features (one per line)</label><textarea name="app_features" rows="4"><?= $g('app_features') ?></textarea></div>
    </div>
  </div>

  <div class="glass p-5">
    <h3 class="font-bold mb-3"><i class="fa-solid fa-palette text-violet-500 mr-1"></i>Brand Colors</h3>
    <div class="grid md:grid-cols-4 gap-3">
      <div><label class="text-xs uppercase font-semibold text-slate-400">Primary (blue)</label><input name="primary_color" type="color" class="input mt-1 h-12" value="<?= $g('primary_color') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Accent (orange)</label><input name="accent_color" type="color" class="input mt-1 h-12" value="<?= $g('accent_color') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Gold</label><input name="gold_color" type="color" class="input mt-1 h-12" value="<?= $g('gold_color') ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Navy (footer)</label><input name="navy_color" type="color" class="input mt-1 h-12" value="<?= $g('navy_color') ?>"></div>
    </div>
  </div>

  <div class="glass p-5">
    <h3 class="font-bold mb-3"><i class="fa-solid fa-shield-halved text-emerald-500 mr-1"></i>Admin Account</h3>
    <div class="grid md:grid-cols-2 gap-3">
      <div><label class="text-xs uppercase font-semibold text-slate-400">Username</label><input class="input mt-1 opacity-60" disabled value="<?= e($ADMIN['username']) ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">New password (leave blank to keep)</label><input name="admin_pw" type="password" class="input mt-1" placeholder="Min 6 chars"></div>
    </div>
  </div>

  <div class="sticky bottom-4 z-10">
    <button class="btn btn-primary w-full justify-center text-base py-3"><i class="fa-solid fa-floppy-disk"></i>Save All Settings</button>
  </div>
</form>
<?php require __DIR__ . '/common/footer.php'; ?>
