<?php
$pageTitle = 'Payment Methods';
require __DIR__ . '/common/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { header('Location: payments.php'); exit; }
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $name = sanitize($_POST['name'] ?? '');
        $num = sanitize($_POST['number'] ?? '');
        $desc = trim((string)($_POST['description'] ?? ''));
        $sort = (int)($_POST['sort_order'] ?? 0);
        $stat = $_POST['status'] === 'inactive' ? 'inactive' : 'active';
        $logo = $_POST['logo_url'] ?? ''; $qr = $_POST['qr_url'] ?? '';
        if (!empty($_FILES['logo']['name'])) { $u = save_upload($_FILES['logo'], 'payments'); if ($u) $logo = $u; }
        if (!empty($_FILES['qr']['name'])) { $u = save_upload($_FILES['qr'], 'payments'); if ($u) $qr = $u; }
        if ($id) {
            $pdo->prepare("UPDATE payment_methods SET name=?, number=?, description=?, sort_order=?, status=?,
                logo=COALESCE(NULLIF(?,''),logo), qr_image=COALESCE(NULLIF(?,''),qr_image) WHERE id=?")
                ->execute([$name, $num, $desc, $sort, $stat, $logo, $qr, $id]);
        } else {
            $pdo->prepare("INSERT INTO payment_methods (name, number, description, sort_order, status, logo, qr_image) VALUES (?,?,?,?,?,?,?)")
                ->execute([$name, $num, $desc, $sort, $stat, $logo, $qr]);
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM payment_methods WHERE id=?")->execute([(int)$_POST['id']]);
    }
    header('Location: payments.php'); exit;
}

$rows = $pdo->query("SELECT * FROM payment_methods ORDER BY sort_order, id")->fetchAll();
$edit = null;
if (isset($_GET['edit'])) { $st = $pdo->prepare("SELECT * FROM payment_methods WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit = $st->fetch() ?: null; }
?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-2xl font-extrabold">Payment Methods</h1>
  <a href="?edit=new" class="btn btn-primary"><i class="fa-solid fa-plus"></i>Add</a>
</div>

<?php if ($edit !== null || ($_GET['edit'] ?? '') === 'new'): $e = $edit ?: []; ?>
<div class="glass p-5 mb-5">
  <h3 class="font-bold mb-3"><?= $edit ? 'Edit' : 'Add' ?> Payment Method</h3>
  <form method="post" enctype="multipart/form-data" class="grid md:grid-cols-2 gap-3">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)($e['id'] ?? 0) ?>">
    <div><label class="text-xs uppercase font-semibold text-slate-400">Name</label><input name="name" class="input mt-1" required value="<?= e($e['name'] ?? '') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Number</label><input name="number" class="input mt-1" required value="<?= e($e['number'] ?? '') ?>"></div>
    <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Description</label><textarea name="description" rows="2" class="mt-1"><?= e($e['description'] ?? '') ?></textarea></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Logo URL or upload</label>
      <input name="logo_url" class="input mt-1" value="<?= e($e['logo'] ?? '') ?>">
      <input type="file" name="logo" accept="image/*" class="mt-2 text-xs"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">QR Image URL or upload</label>
      <input name="qr_url" class="input mt-1" value="<?= e($e['qr_image'] ?? '') ?>">
      <input type="file" name="qr" accept="image/*" class="mt-2 text-xs"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Sort</label><input name="sort_order" type="number" class="input mt-1" value="<?= (int)($e['sort_order'] ?? 0) ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Status</label>
      <select name="status" class="select mt-1"><option value="active" <?= ($e['status'] ?? 'active')==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= ($e['status'] ?? '')==='inactive'?'selected':'' ?>>Inactive</option></select></div>
    <div class="md:col-span-2 flex gap-2"><button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i>Save</button><a href="payments.php" class="btn btn-ghost">Cancel</a></div>
  </form>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
  <?php foreach ($rows as $p): ?>
  <div class="glass p-4">
    <div class="flex items-center gap-3 mb-3">
      <img src="<?= e($p['logo']) ?>" class="w-16 h-12 object-contain bg-white/5 rounded-lg p-1">
      <div class="flex-1">
        <div class="font-bold"><?= e($p['name']) ?></div>
        <div class="text-xs text-slate-500 font-mono"><?= e($p['number']) ?></div>
      </div>
      <span class="pill <?= $p['status']==='active'?'bg-emerald-500':'bg-rose-500' ?> text-white"><?= ucfirst($p['status']) ?></span>
    </div>
    <p class="text-xs text-slate-400 line-clamp-2 mb-3"><?= e($p['description']) ?></p>
    <div class="flex gap-2">
      <a href="?edit=<?= (int)$p['id'] ?>" class="btn btn-ghost flex-1 justify-center"><i class="fa-solid fa-pen"></i>Edit</a>
      <form method="post" onsubmit="return confirmAction('Delete this method?')" class="flex-1">
        <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
        <button class="btn btn-danger w-full justify-center"><i class="fa-solid fa-trash"></i>Delete</button>
      </form>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>
