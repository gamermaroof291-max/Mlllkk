<?php
$pageTitle = 'Helplines';
require __DIR__ . '/common/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { header('Location: helplines.php'); exit; }
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $title    = sanitize($_POST['title'] ?? '');
        $subtitle = sanitize($_POST['subtitle'] ?? '');
        $icon     = sanitize($_POST['icon'] ?? 'fa-phone');
        $link     = sanitize($_POST['link'] ?? '');
        $sort     = (int)($_POST['sort_order'] ?? 0);
        $status   = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
        if ($id) {
            $pdo->prepare("UPDATE helplines SET title=?, subtitle=?, icon=?, link=?, sort_order=?, status=? WHERE id=?")
                ->execute([$title,$subtitle,$icon,$link,$sort,$status,$id]);
        } else {
            $pdo->prepare("INSERT INTO helplines (title, subtitle, icon, link, sort_order, status) VALUES (?,?,?,?,?,?)")
                ->execute([$title,$subtitle,$icon,$link,$sort,$status]);
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM helplines WHERE id=?")->execute([(int)$_POST['id']]);
    }
    header('Location: helplines.php'); exit;
}

$rows = $pdo->query("SELECT * FROM helplines ORDER BY sort_order ASC, id ASC")->fetchAll();
$edit = null;
if (isset($_GET['edit'])) { $st=$pdo->prepare("SELECT * FROM helplines WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit = $st->fetch(); }
?>
<div class="flex items-center justify-between mb-4">
  <div>
    <h1 class="text-2xl font-extrabold">Helplines (Footer Support Center)</h1>
    <p class="text-sm text-slate-400 mt-1">Cards shown in the dark footer "SUPPORT CENTER" section.</p>
  </div>
  <a href="helplines.php?edit=new" class="btn btn-primary"><i class="fa-solid fa-plus"></i>Add Helpline</a>
</div>

<?php if ($edit !== null || ($_GET['edit'] ?? '') === 'new'): $e = $edit ?: []; ?>
<div class="glass p-5 mb-5">
  <h3 class="font-bold mb-3"><?= $edit ? 'Edit' : 'Add' ?> Helpline</h3>
  <form method="post" class="grid md:grid-cols-2 gap-3">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)($e['id'] ?? 0) ?>">
    <div><label class="text-xs uppercase font-semibold text-slate-400">Title (line 1)</label>
      <input name="title" class="input mt-1" required value="<?= e($e['title'] ?? 'Help line [9AM-12PM]') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Subtitle (line 2)</label>
      <input name="subtitle" class="input mt-1" value="<?= e($e['subtitle'] ?? 'Whatsapp HelpLine') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Icon class</label>
      <input name="icon" class="input mt-1" placeholder="fa-whatsapp / fa-telegram / fa-phone" value="<?= e($e['icon'] ?? 'fa-whatsapp') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Link (URL)</label>
      <input name="link" class="input mt-1" placeholder="https://wa.me/..." value="<?= e($e['link'] ?? '') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Sort order</label>
      <input name="sort_order" type="number" class="input mt-1" value="<?= (int)($e['sort_order'] ?? 0) ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Status</label>
      <select name="status" class="select mt-1">
        <option value="active" <?= ($e['status'] ?? 'active')==='active'?'selected':'' ?>>Active</option>
        <option value="inactive" <?= ($e['status'] ?? '')==='inactive'?'selected':'' ?>>Inactive</option>
      </select></div>
    <div class="md:col-span-2 flex gap-2">
      <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i>Save</button>
      <a href="helplines.php" class="btn btn-ghost">Cancel</a>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="glass overflow-x-auto">
  <table>
    <thead><tr><th>Icon</th><th>Title</th><th>Subtitle</th><th>Link</th><th>Status</th><th>Sort</th><th></th></tr></thead>
    <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7" class="text-center text-slate-500 py-6">No helplines yet — add one to populate the footer.</td></tr>
      <?php else: foreach ($rows as $r): ?>
        <tr class="row-link">
          <td><div class="w-9 h-9 rounded-full border border-white/20 flex items-center justify-center"><i class="<?= (str_contains($r['icon']??'','wha')||str_contains($r['icon']??'','tele')||str_contains($r['icon']??'','face')||str_contains($r['icon']??'','insta')||str_contains($r['icon']??'','you'))?'fa-brands':'fa-solid' ?> <?= e($r['icon']) ?>"></i></div></td>
          <td class="font-bold"><?= e($r['title']) ?></td>
          <td class="text-slate-400"><?= e($r['subtitle']) ?></td>
          <td class="text-xs text-primary truncate max-w-xs"><?= e($r['link']) ?></td>
          <td><span class="pill <?= $r['status']==='active'?'bg-emerald-500':'bg-slate-500' ?> text-white"><?= ucfirst(e($r['status'])) ?></span></td>
          <td><?= (int)$r['sort_order'] ?></td>
          <td class="flex gap-1">
            <a href="helplines.php?edit=<?= (int)$r['id'] ?>" class="btn btn-ghost"><i class="fa-solid fa-pen"></i></a>
            <form method="post" onsubmit="return confirmAction('Delete this helpline?')" class="inline">
              <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>
