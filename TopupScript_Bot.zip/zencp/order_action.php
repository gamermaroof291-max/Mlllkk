<?php
require_once __DIR__ . '/common/auth.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) json_err('Bad CSRF');
    $id = (int)($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? '';
    $code = trim((string)($_POST['code'] ?? ''));
    $note = trim((string)($_POST['note'] ?? ''));

    $st = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $st->execute([$id]);
    $order = $st->fetch();
    if (!$order) json_err('Order not found');

    if (!in_array($status, ['completed','failed','cancelled','pending'], true)) json_err('Invalid status');

    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE orders SET status = ?, admin_note = ? WHERE id = ?")
            ->execute([$status, $note ?: null, $id]);

        // If completing & code provided → save code
        if ($status === 'completed' && $code !== '') {
            // Insert as redeem code first
            $pdo->prepare("INSERT INTO redeem_codes (cat_id, product_id, code, status, assigned_order_id, used_at) VALUES (?, ?, ?, 'used', ?, CURRENT_TIMESTAMP)")
                ->execute([$order['cat_id'], $order['product_id'], $code, $id]);
            $codeId = (int)$pdo->lastInsertId();
            $pdo->prepare("INSERT INTO order_codes (order_id, code_id, code) VALUES (?, ?, ?)")
                ->execute([$id, $codeId, $code]);
        }

        // Refund wallet on failed/cancelled if was wallet-paid
        if (in_array($status, ['failed','cancelled'], true) && $order['payment_method'] === 'wallet' && $order['status'] !== $status) {
            $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")
                ->execute([$order['total_amount'], $order['user_id']]);
            $pdo->prepare("INSERT INTO transactions (user_id, type, amount, note, ref_id) VALUES (?, 'refund', ?, ?, ?)")
                ->execute([$order['user_id'], $order['total_amount'], 'Refund for ' . $order['order_code'], $order['order_code']]);
        }

        // For manual orders that are completed → record a transaction (revenue)
        if ($status === 'completed' && $order['payment_method'] === 'manual') {
            $pdo->prepare("INSERT INTO transactions (user_id, type, amount, note, ref_id) VALUES (?, 'order', ?, ?, ?)")
                ->execute([$order['user_id'], -$order['total_amount'], 'Manual order ' . $order['order_code'], $order['order_code']]);
        }

        $pdo->commit();
        json_ok('Updated');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        json_err($e->getMessage(), 500);
    }
}

// GET — modal HTML
$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare("SELECT o.*, u.name AS user_name, u.phone AS user_phone, c.name AS game_name, c.type AS game_type, p.name AS product_name, pm.name AS pm_name
  FROM orders o JOIN users u ON u.id=o.user_id JOIN categories c ON c.id=o.cat_id JOIN products p ON p.id=o.product_id LEFT JOIN payment_methods pm ON pm.id=o.payment_method_id
  WHERE o.id = ?");
$st->execute([$id]);
$o = $st->fetch();
if (!$o) { echo '<div class="text-rose-400">Order not found.</div>'; exit; }

$existingCode = $pdo->prepare("SELECT code FROM order_codes WHERE order_id=?");
$existingCode->execute([$id]);
$ec = $existingCode->fetchColumn();
?>
<div class="space-y-3 text-sm">
  <div class="grid grid-cols-2 gap-3">
    <div><div class="text-xs text-slate-400">Order</div><div class="font-mono font-bold"><?= e($o['order_code']) ?></div></div>
    <div><div class="text-xs text-slate-400">Status</div><div class="font-bold capitalize"><?= e($o['status']) ?></div></div>
    <div><div class="text-xs text-slate-400">User</div><div class="font-bold"><?= e($o['user_name']) ?></div><div class="text-xs"><?= e($o['user_phone']) ?></div></div>
    <div><div class="text-xs text-slate-400">Amount</div><div class="font-bold text-primary"><?= format_money($o['total_amount']) ?></div></div>
    <div class="col-span-2"><div class="text-xs text-slate-400">Game / Product</div><div><?= e($o['game_name']) ?> · <span class="text-slate-400"><?= e($o['product_name']) ?></span></div></div>
    <?php if ($o['player_uid']): ?><div><div class="text-xs text-slate-400">Player UID</div><div class="font-mono"><?= e($o['player_uid']) ?></div></div><?php endif; ?>
    <?php if ($o['zone_id']): ?><div><div class="text-xs text-slate-400">Zone</div><div class="font-mono"><?= e($o['zone_id']) ?></div></div><?php endif; ?>
    <div class="col-span-2"><div class="text-xs text-slate-400">Payment</div>
      <?php if ($o['payment_method']==='wallet'): ?>
        <span class="pill bg-emerald-500 text-white">Wallet</span>
      <?php else: ?>
        <span class="pill bg-pink-500 text-white"><?= e($o['pm_name']) ?></span>
        <span class="text-xs text-slate-400 ml-2">TxnID: <code><?= e($o['trx_id']) ?></code> · From: <code><?= e($o['sender_number']) ?></code></span>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($ec): ?>
    <div class="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3">
      <div class="text-xs font-bold text-emerald-300 mb-1">Delivered code</div>
      <code class="font-mono break-all"><?= e($ec) ?></code>
    </div>
  <?php endif; ?>

  <?php if ($o['status'] === 'pending'): ?>
    <hr class="border-white/10">
    <?php if ($o['game_type'] === 'voucher' && !$ec): ?>
      <div><label class="text-xs font-semibold uppercase text-slate-400">Voucher code (will be sent to user)</label>
        <textarea id="vCode" class="mt-1" rows="2" placeholder="Paste the redeem code here"></textarea></div>
    <?php endif; ?>
    <div><label class="text-xs font-semibold uppercase text-slate-400">Note (optional, shown to user)</label>
      <input id="vNote" class="input mt-1" placeholder="e.g. Diamonds delivered"></div>
    <div class="flex gap-2 pt-2">
      <button onclick="actOrder(<?= $id ?>, 'completed', document.getElementById('vCode')?document.getElementById('vCode').value.trim():'', document.getElementById('vNote').value.trim())" class="btn btn-success flex-1"><i class="fa-solid fa-check"></i>Mark Completed</button>
      <button onclick="actOrder(<?= $id ?>, 'failed', '', document.getElementById('vNote').value.trim())" class="btn btn-danger"><i class="fa-solid fa-xmark"></i>Failed</button>
      <button onclick="actOrder(<?= $id ?>, 'cancelled', '', document.getElementById('vNote').value.trim())" class="btn btn-warn"><i class="fa-solid fa-ban"></i>Cancel</button>
    </div>
  <?php endif; ?>
</div>
