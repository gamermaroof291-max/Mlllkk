<?php
$pageTitle = 'Products';
require __DIR__ . '/common/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { header('Location: products.php'); exit; }
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $cat = (int)($_POST['cat_id'] ?? 0);
        $name = sanitize($_POST['name'] ?? '');
        $price = (float)($_POST['price'] ?? 0);
        $stock = isset($_POST['stock']) && $_POST['stock'] !== '' ? (int)$_POST['stock'] : -1;
        $sort = (int)($_POST['sort_order'] ?? 0);
        $featured = !empty($_POST['featured']) ? 1 : 0;
        $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';
        if ($id) {
            $pdo->prepare("UPDATE products SET cat_id=?, name=?, price=?, stock=?, sort_order=?, featured=?, status=? WHERE id=?")
                ->execute([$cat, $name, $price, $stock, $sort, $featured, $status, $id]);
        } else {
            $pdo->prepare("INSERT INTO products (cat_id, name, price, stock, sort_order, featured, status) VALUES (?,?,?,?,?,?,?)")
                ->execute([$cat, $name, $price, $stock, $sort, $featured, $status]);
        }
    } elseif ($action === 'delete') {
        $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([(int)$_POST['id']]);
    }
    header('Location: products.php' . (isset($_GET['cat']) ? '?cat=' . (int)$_GET['cat'] : '')); exit;
}

$cats = $pdo->query("SELECT id, name FROM categories ORDER BY sort_order, id")->fetchAll();
$catFilter = (int)($_GET['cat'] ?? 0);
$where = ''; $params = [];
if ($catFilter) { $where = "WHERE p.cat_id = ?"; $params[] = $catFilter; }
$rows = $pdo->prepare("SELECT p.*, c.name AS cat_name FROM products p JOIN categories c ON c.id = p.cat_id $where ORDER BY c.sort_order, p.sort_order, p.id");
$rows->execute($params); $products = $rows->fetchAll();

$edit = null;
if (isset($_GET['edit'])) { $st = $pdo->prepare("SELECT * FROM products WHERE id=?"); $st->execute([(int)$_GET['edit']]); $edit = $st->fetch() ?: null; }
?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-2xl font-extrabold">Products</h1>
  <div class="flex gap-2 items-center">
    <select onchange="location.href='products.php' + (this.value?'?cat='+this.value:'')" class="select" style="max-width:200px">
      <option value="">All games</option>
      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $catFilter===(int)$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
    </select>
    <a href="products.php?edit=new<?= $catFilter?'&cat='.$catFilter:'' ?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i>Add</a>
  </div>
</div>

<?php if ($edit !== null || ($_GET['edit'] ?? '') === 'new'): $e = $edit ?: ['cat_id'=>$catFilter]; ?>
<div class="glass p-5 mb-5">
  <h3 class="font-bold mb-3"><?= $edit ? 'Edit' : 'Add' ?> Product</h3>
  <form method="post" class="grid md:grid-cols-3 gap-3">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)($e['id'] ?? 0) ?>">

    <div><label class="text-xs uppercase font-semibold text-slate-400">Game</label>
      <select name="cat_id" class="select mt-1" required>
        <option value="">— select —</option>
        <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= ($e['cat_id'] ?? 0)==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
      </select></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Name</label>
      <input name="name" class="input mt-1" required value="<?= e($e['name'] ?? '') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Price (<?= e(setting('currency_symbol','৳')) ?>)</label>
      <input name="price" type="number" step="0.01" class="input mt-1" required value="<?= e($e['price'] ?? '') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Stock <span class="text-slate-500 normal-case">(-1 = unlimited)</span></label>
      <input name="stock" type="number" class="input mt-1" value="<?= e($e['stock'] ?? '-1') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Sort</label>
      <input name="sort_order" type="number" class="input mt-1" value="<?= (int)($e['sort_order'] ?? 0) ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Status</label>
      <select name="status" class="select mt-1"><option value="active" <?= ($e['status'] ?? 'active')==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= ($e['status'] ?? '')==='inactive'?'selected':'' ?>>Inactive</option></select></div>
    <div class="flex items-end"><label><input type="checkbox" name="featured" <?= !empty($e['featured'])?'checked':'' ?>> Featured (HOT)</label></div>

    <div class="md:col-span-3 flex gap-2"><button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i>Save</button><a href="products.php<?= $catFilter?'?cat='.$catFilter:'' ?>" class="btn btn-ghost">Cancel</a></div>
  </form>
</div>
<?php endif; ?>

<div class="glass overflow-x-auto">
  <table class="w-full">
    <thead><tr><th>Game</th><th>Name</th><th>Price</th><th>Stock</th><th>Featured</th><th>Status</th><th>Sort</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($products as $p): ?>
      <tr class="row-link">
        <td class="text-slate-400"><?= e($p['cat_name']) ?></td>
        <td class="font-semibold"><?= e($p['name']) ?></td>
        <td class="font-bold text-primary"><?= format_money($p['price']) ?></td>
        <td><?= $p['stock'] < 0 ? '∞' : (int)$p['stock'] ?></td>
        <td><?= $p['featured'] ? '<span class="pill bg-amber-500 text-white">HOT</span>' : '' ?></td>
        <td><span class="pill <?= $p['status']==='active'?'bg-emerald-500':'bg-rose-500' ?> text-white"><?= ucfirst(e($p['status'])) ?></span></td>
        <td><?= (int)$p['sort_order'] ?></td>
        <td class="flex gap-1">
          <a href="?edit=<?= (int)$p['id'] ?><?= $catFilter?'&cat='.$catFilter:'' ?>" class="btn btn-ghost"><i class="fa-solid fa-pen"></i></a>
          <form method="post" onsubmit="return confirmAction('Delete this product?')" class="inline">
            <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$products): ?><tr><td colspan="8" class="text-center text-slate-500 py-8">No products.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>
