<?php
require_once __DIR__ . '/../common/config.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { $err = 'Session expired.'; }
    else {
        $u = trim($_POST['username'] ?? '');
        $p = $_POST['password'] ?? '';
        $stmt = db()->prepare("SELECT * FROM admin WHERE username = ?");
        $stmt->execute([$u]);
        $a = $stmt->fetch();
        if (!$a || !password_verify($p, $a['password'])) {
            $err = 'Invalid admin credentials.';
        } else {
            $_SESSION['aid'] = $a['id'];
            db()->prepare("UPDATE admin SET last_login = CURRENT_TIMESTAMP WHERE id = ?")->execute([$a['id']]);
            header('Location: ' . site_url('zencp/index.php')); exit;
        }
    }
}
if (admin_user()) { header('Location: ' . site_url('zencp/index.php')); exit; }
?>
<!doctype html>
<html lang="en" class="dark">
<head><meta charset="utf-8"><title>Admin Login — Code Zen</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:'Inter',sans-serif;background:#0B0B16;color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem;}
.bg-orbs{position:fixed;inset:0;z-index:-1;overflow:hidden;}
.bg-orbs::before,.bg-orbs::after{content:"";position:absolute;border-radius:50%;filter:blur(100px);opacity:.4;}
.bg-orbs::before{width:400px;height:400px;background:#6C63FF;top:-100px;left:-80px;}
.bg-orbs::after{width:400px;height:400px;background:#A855F7;bottom:-100px;right:-80px;}
.glass{background:rgba(255,255,255,.05);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.1);border-radius:18px;}
.input{width:100%;padding:.8rem 1rem;border-radius:12px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);color:#fff;}
.input:focus{outline:none;border-color:#6C63FF;}
</style></head>
<body>
<div class="bg-orbs"></div>
<div class="glass p-8 w-full max-w-sm">
  <div class="text-center mb-6">
    <div class="inline-flex w-14 h-14 rounded-2xl bg-gradient-to-br from-[#6C63FF] to-[#A855F7] items-center justify-center text-white font-extrabold mb-3 shadow-lg">CZ</div>
    <h1 class="text-2xl font-extrabold">Admin Panel</h1>
    <p class="text-sm text-slate-400 mt-1">Sign in to manage Code Zen</p>
  </div>
  <?php if ($err): ?><div class="bg-red-500/15 border border-red-500/30 text-red-400 rounded-xl p-3 mb-3 text-sm"><?= e($err) ?></div><?php endif; ?>
  <form method="post" class="space-y-3">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <div><label class="text-xs font-semibold uppercase text-slate-400">Username</label>
      <input name="username" class="input mt-1" placeholder="admin" required autofocus></div>
    <div><label class="text-xs font-semibold uppercase text-slate-400">Password</label>
      <input name="password" type="password" class="input mt-1" placeholder="••••••••" required></div>
    <button class="w-full mt-2 py-3 rounded-xl bg-gradient-to-r from-[#6C63FF] to-[#A855F7] text-white font-bold"><i class="fa-solid fa-shield-halved mr-1"></i> Sign in</button>
  </form>
  <div class="text-center text-xs text-slate-500 mt-4">Default: <code class="bg-white/5 px-2 py-0.5 rounded">admin / codezen@2025</code></div>
</div>
</body></html>
