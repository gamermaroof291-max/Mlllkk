<?php
require_once __DIR__ . '/../common/config.php';
unset($_SESSION['aid']);
session_regenerate_id(true);
header('Location: ' . site_url('zencp/login.php'));
exit;
