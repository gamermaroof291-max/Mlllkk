<?php
$pageTitle = 'Games';
require __DIR__ . '/common/header.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['_csrf'] ?? '')) { header('Location: games.php'); exit; }
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $id    = (int)($_POST['id'] ?? 0);
        $name  = sanitize($_POST['name'] ?? '');
        $section = sanitize($_POST['section'] ?? 'Featured');
        $type  = in_array($_POST['type'] ?? '', ['uid','voucher'], true) ? $_POST['type'] : 'uid';
        $desc  = trim((string)($_POST['description'] ?? ''));
        $rules = trim((string)($_POST['rules'] ?? ''));
        $zone  = !empty($_POST['zone_required']) ? 1 : 0;
        $stat  = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
        $sort  = (int)($_POST['sort_order'] ?? 0);
        $img   = $_POST['image_url'] ?? '';
        if (!empty($_FILES['image']['name'])) {
            $up = save_upload($_FILES['image'], 'games');
            if ($up) $img = $up;
        }
        if ($id) {
            $pdo->prepare("UPDATE categories SET name=?, section=?, type=?, description=?, rules=?, zone_required=?, status=?, sort_order=?, image=COALESCE(NULLIF(?,''), image) WHERE id=?")
                ->execute([$name, $section, $type, $desc, $rules, $zone, $stat, $sort, $img, $id]);
        } else {
            $pdo->prepare("INSERT INTO categories (name, section, type, description, rules, image, zone_required, status, sort_order) VALUES (?,?,?,?,?,?,?,?,?)")
                ->execute([$name, $section, $type, $desc, $rules, $img, $zone, $stat, $sort]);
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
    }
    header('Location: games.php'); exit;
}

$games = $pdo->query("SELECT g.*, (SELECT COUNT(*) FROM products WHERE cat_id = g.id) AS prod_count FROM categories g ORDER BY sort_order ASC, id ASC")->fetchAll();
$edit = null;
if (isset($_GET['edit'])) {
    $st = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $st->execute([(int)$_GET['edit']]); $edit = $st->fetch() ?: null;
}
?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-2xl font-extrabold">Games</h1>
  <a href="games.php?edit=new" class="btn btn-primary"><i class="fa-solid fa-plus"></i>Add Game</a>
</div>

<?php if ($edit !== null || ($_GET['edit'] ?? '') === 'new'): $e = $edit ?: []; ?>
<div class="glass p-5 mb-5">
  <h3 class="font-bold mb-3"><?= $edit ? 'Edit' : 'Add' ?> Game</h3>
  <form method="post" enctype="multipart/form-data" class="grid md:grid-cols-2 gap-3">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)($e['id'] ?? 0) ?>">

    <div><label class="text-xs uppercase font-semibold text-slate-400">Name</label>
      <input name="name" class="input mt-1" required value="<?= e($e['name'] ?? '') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Section heading (groups games on home)</label>
      <input name="section" class="input mt-1" placeholder="FREE FIRE / PUBG MOBILE / VOUCHER CODE" value="<?= e($e['section'] ?? 'Featured') ?>"></div>
    <div><label class="text-xs uppercase font-semibold text-slate-400">Type</label>
      <select name="type" class="select mt-1">
        <option value="uid" <?= ($e['type'] ?? '')==='uid'?'selected':'' ?>>UID Top-up (Direct)</option>
        <option value="voucher" <?= ($e['type'] ?? '')==='voucher'?'selected':'' ?>>Voucher Code</option>
      </select></div>

    <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Description (short)</label>
      <textarea name="description" class="mt-1" rows="2"><?= e($e['description'] ?? '') ?></textarea></div>
    <div class="md:col-span-2"><label class="text-xs uppercase font-semibold text-slate-400">Rules / Notes (detailed)</label>
      <textarea name="rules" class="mt-1" rows="3"><?= e($e['rules'] ?? '') ?></textarea></div>

    <div><label class="text-xs uppercase font-semibold text-slate-400">Image URL or upload</label>
      <input name="image_url" class="input mt-1" placeholder="https://..." value="<?= e($e['image'] ?? '') ?>">
      <input name="image" type="file" accept="image/*" class="mt-2 text-xs"></div>
    <div class="grid grid-cols-3 gap-3">
      <div><label class="text-xs uppercase font-semibold text-slate-400">Sort</label>
        <input name="sort_order" type="number" class="input mt-1" value="<?= (int)($e['sort_order'] ?? 0) ?>"></div>
      <div><label class="text-xs uppercase font-semibold text-slate-400">Status</label>
        <select name="status" class="select mt-1"><option value="active" <?= ($e['status'] ?? 'active')==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= ($e['status'] ?? '')==='inactive'?'selected':'' ?>>Inactive</option></select></div>
      <div class="flex items-end"><label class="text-xs"><input type="checkbox" name="zone_required" <?= !empty($e['zone_required'])?'checked':'' ?>> Zone ID required</label></div>
    </div>

    <div class="md:col-span-2 flex gap-2">
      <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i>Save</button>
      <a href="games.php" class="btn btn-ghost">Cancel</a>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="glass overflow-x-auto">
  <table class="w-full">
    <thead><tr><th>Image</th><th>Name</th><th>Section</th><th>Type</th><th>Products</th><th>Status</th><th>Sort</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($games as $g): ?>
      <tr class="row-link">
        <td><img src="<?= e($g['image'] ?: 'https://placehold.co/60x60') ?>" class="w-10 h-10 rounded-lg object-cover"></td>
        <td class="font-semibold"><?= e($g['name']) ?></td>
        <td><span class="pill bg-primary/20 text-primary"><?= e($g['section'] ?? 'Featured') ?></span></td>
        <td><span class="pill bg-violet-500/20 text-violet-300"><?= ucfirst(e($g['type'])) ?></span></td>
        <td><a href="products.php?cat=<?= (int)$g['id'] ?>" class="text-primary font-bold"><?= (int)$g['prod_count'] ?></a></td>
        <td><span class="pill <?= $g['status']==='active'?'bg-emerald-500':'bg-rose-500' ?> text-white"><?= ucfirst(e($g['status'])) ?></span></td>
        <td><?= (int)$g['sort_order'] ?></td>
        <td class="flex gap-1">
          <a href="games.php?edit=<?= (int)$g['id'] ?>" class="btn btn-ghost"><i class="fa-solid fa-pen"></i></a>
          <form method="post" onsubmit="return confirmAction('Delete this game and ALL its products?')" class="inline">
            <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$g['id'] ?>">
            <button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>
