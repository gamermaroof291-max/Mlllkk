<?php
$pageTitle = 'Orders';
require __DIR__ . '/common/header.php';

$status = $_GET['status'] ?? 'all';
$where = ''; $params = [];
if (in_array($status, ['pending','completed','failed','cancelled'], true)) {
    $where = "WHERE o.status = ?"; $params[] = $status;
}
$sql = "SELECT o.*, u.name AS user_name, u.phone AS user_phone, c.name AS game_name, p.name AS product_name, pm.name AS pm_name
        FROM orders o
        JOIN users u ON u.id = o.user_id
        JOIN categories c ON c.id = o.cat_id
        JOIN products p ON p.id = o.product_id
        LEFT JOIN payment_methods pm ON pm.id = o.payment_method_id
        $where ORDER BY o.id DESC LIMIT 200";
$st = db()->prepare($sql); $st->execute($params); $orders = $st->fetchAll();
?>

<div class="flex items-center justify-between mb-4">
  <h1 class="text-2xl font-extrabold">Orders <span class="text-slate-500 text-base font-normal">(<?= count($orders) ?>)</span></h1>
  <div class="flex gap-2">
    <?php foreach (['all','pending','completed','failed','cancelled'] as $s): ?>
      <a href="?status=<?= $s ?>" class="btn <?= $status===$s?'btn-primary':'btn-ghost' ?>"><?= ucfirst($s) ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="glass overflow-x-auto">
  <table class="w-full">
    <thead><tr>
      <th>Code</th><th>User</th><th>Game / Product</th><th>UID/Zone</th><th>Payment</th><th>Amount</th><th>Status</th><th>Date</th><th></th>
    </tr></thead>
    <tbody>
      <?php foreach ($orders as $o):
        $col = ['pending'=>'bg-amber-500','completed'=>'bg-emerald-500','failed'=>'bg-rose-500','cancelled'=>'bg-slate-500'][$o['status']] ?? 'bg-slate-500';
      ?>
      <tr class="row-link">
        <td class="font-mono text-xs"><?= e($o['order_code']) ?></td>
        <td><div class="font-semibold"><?= e($o['user_name']) ?></div><div class="text-xs text-slate-500"><?= e($o['user_phone']) ?></div></td>
        <td><div class="font-semibold"><?= e($o['game_name']) ?></div><div class="text-xs text-slate-500"><?= e($o['product_name']) ?></div></td>
        <td class="text-xs font-mono"><?= e($o['player_uid']) ?><?= $o['zone_id'] ? '<br>Z: '.e($o['zone_id']) : '' ?></td>
        <td>
          <?php if ($o['payment_method'] === 'wallet'): ?>
            <span class="pill bg-emerald-500/20 text-emerald-300">Wallet</span>
          <?php else: ?>
            <div class="text-xs"><?= e($o['pm_name']) ?></div>
            <div class="text-[10px] text-slate-500">TxnID: <?= e($o['trx_id']) ?></div>
            <div class="text-[10px] text-slate-500"><?= e($o['sender_number']) ?></div>
          <?php endif; ?>
        </td>
        <td class="font-bold text-primary"><?= format_money($o['total_amount']) ?></td>
        <td><span class="pill <?= $col ?> text-white"><?= ucfirst($o['status']) ?></span></td>
        <td class="text-xs text-slate-500"><?= time_ago($o['created_at']) ?></td>
        <td>
          <?php if ($o['status'] === 'pending'): ?>
            <button onclick="openOrder(<?= (int)$o['id'] ?>)" class="btn btn-primary"><i class="fa-solid fa-pen"></i></button>
          <?php else: ?>
            <button onclick="openOrder(<?= (int)$o['id'] ?>)" class="btn btn-ghost"><i class="fa-solid fa-eye"></i></button>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$orders): ?><tr><td colspan="9" class="text-center text-slate-500 py-8">No orders found.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Modal -->
<div id="modal" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
  <div class="glass w-full max-w-lg p-5">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-bold text-lg">Process Order</h3>
      <button onclick="document.getElementById('modal').classList.add('hidden')" class="text-slate-400"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div id="modalBody"></div>
  </div>
</div>

<script>
async function openOrder(id){
  var r = await fetch('order_action.php?id=' + id);
  var html = await r.text();
  document.getElementById('modalBody').innerHTML = html;
  document.getElementById('modal').classList.remove('hidden');
}
async function actOrder(id, status, code, note){
  var fd = new FormData();
  fd.append('id', id); fd.append('status', status); fd.append('_csrf', '<?= e(csrf_token()) ?>');
  if (code !== undefined) fd.append('code', code);
  if (note !== undefined) fd.append('note', note);
  var r = await fetch('order_action.php', { method:'POST', body: fd });
  var j = await r.json();
  if (j.success) { window.czToast('Order updated', 'success'); setTimeout(()=>location.reload(), 500); }
  else window.czToast(j.message || 'Error', 'error');
}
</script>
<?php require __DIR__ . '/common/footer.php'; ?>
