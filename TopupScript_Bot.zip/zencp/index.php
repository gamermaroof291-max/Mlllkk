<?php
$pageTitle = 'Dashboard';
require __DIR__ . '/common/header.php';

$pdo = db();
function scalar(PDO $pdo, string $sql, array $p = []): float {
    $st = $pdo->prepare($sql); $st->execute($p);
    return (float)$st->fetchColumn();
}
$stats = [
    'users' => (int)scalar($pdo, "SELECT COUNT(*) FROM users"),
    'orders' => (int)scalar($pdo, "SELECT COUNT(*) FROM orders"),
    'pending_orders' => (int)scalar($pdo, "SELECT COUNT(*) FROM orders WHERE status='pending'"),
    'completed_orders' => (int)scalar($pdo, "SELECT COUNT(*) FROM orders WHERE status='completed'"),
    'revenue' => scalar($pdo, "SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status='completed'"),
    'pending_topups' => (int)scalar($pdo, "SELECT COUNT(*) FROM wallet_topup WHERE status='pending'"),
    'wallet_balance' => scalar($pdo, "SELECT COALESCE(SUM(balance),0) FROM users"),
    'games' => (int)scalar($pdo, "SELECT COUNT(*) FROM categories"),
    'codes_avail' => (int)scalar($pdo, "SELECT COUNT(*) FROM redeem_codes WHERE status='unused'"),
];
$recentOrders = $pdo->query("SELECT o.*, u.name AS user_name, c.name AS game_name, p.name AS product_name FROM orders o
  JOIN users u ON u.id = o.user_id JOIN categories c ON c.id = o.cat_id JOIN products p ON p.id = o.product_id
  ORDER BY o.id DESC LIMIT 8")->fetchAll();
$recentTopups = $pdo->query("SELECT w.*, u.name AS user_name, pm.name AS method FROM wallet_topup w
  JOIN users u ON u.id = w.user_id LEFT JOIN payment_methods pm ON pm.id = w.method_id
  ORDER BY w.id DESC LIMIT 6")->fetchAll();
?>
<div class="mb-5 flex items-center justify-between">
  <div>
    <h1 class="text-2xl font-extrabold">Dashboard</h1>
    <p class="text-slate-400 text-sm">Welcome back, <?= e($ADMIN['username']) ?> 👋</p>
  </div>
  <a href="<?= e(site_url('index.php')) ?>" target="_blank" class="btn btn-ghost"><i class="fa-solid fa-arrow-up-right-from-square"></i> View site</a>
</div>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-5">
  <?php
  $cards = [
    ['Total users', $stats['users'], 'fa-users', 'from-violet-500 to-purple-600'],
    ['Total orders', $stats['orders'], 'fa-bag-shopping', 'from-sky-500 to-blue-600'],
    ['Revenue', format_money($stats['revenue']), 'fa-sack-dollar', 'from-emerald-500 to-teal-600'],
    ['Pending orders', $stats['pending_orders'], 'fa-clock', 'from-amber-500 to-orange-600'],
    ['Pending top-ups', $stats['pending_topups'], 'fa-wallet', 'from-rose-500 to-pink-600'],
    ['Completed orders', $stats['completed_orders'], 'fa-circle-check', 'from-green-500 to-emerald-600'],
    ['Total games', $stats['games'], 'fa-gamepad', 'from-fuchsia-500 to-pink-600'],
    ['Codes in stock', $stats['codes_avail'], 'fa-key', 'from-indigo-500 to-violet-600'],
  ];
  foreach ($cards as $c): ?>
    <div class="glass p-4">
      <div class="flex items-center justify-between mb-2">
        <div class="text-xs text-slate-400 font-semibold uppercase"><?= e($c[0]) ?></div>
        <div class="w-9 h-9 rounded-lg bg-gradient-to-br <?= $c[3] ?> text-white flex items-center justify-center"><i class="fa-solid <?= $c[2] ?>"></i></div>
      </div>
      <div class="text-2xl font-extrabold"><?= e($c[1]) ?></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="grid lg:grid-cols-2 gap-4">
  <div class="glass p-4">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-bold"><i class="fa-solid fa-bag-shopping text-primary mr-1"></i>Recent Orders</h3>
      <a href="<?= e(site_url('zencp/orders.php')) ?>" class="text-xs text-primary font-semibold">View all →</a>
    </div>
    <?php if (!$recentOrders): ?>
      <div class="text-slate-500 text-sm text-center py-6">No orders yet.</div>
    <?php else: ?>
      <div class="divide-y divide-white/5">
        <?php foreach ($recentOrders as $o):
          $col = ['pending'=>'bg-amber-500','completed'=>'bg-emerald-500','failed'=>'bg-rose-500','cancelled'=>'bg-slate-500'][$o['status']] ?? 'bg-slate-500';
        ?>
          <div class="py-2.5 flex items-center gap-3 text-sm">
            <div class="flex-1 min-w-0">
              <div class="font-semibold truncate"><?= e($o['game_name']) ?> · <?= e($o['product_name']) ?></div>
              <div class="text-xs text-slate-500"><?= e($o['user_name']) ?> · <?= e($o['order_code']) ?> · <?= time_ago($o['created_at']) ?></div>
            </div>
            <div class="text-right">
              <div class="font-bold text-primary"><?= format_money($o['total_amount']) ?></div>
              <span class="pill <?= $col ?> text-white"><?= ucfirst($o['status']) ?></span>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="glass p-4">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-bold"><i class="fa-solid fa-wallet text-emerald-500 mr-1"></i>Recent Wallet Top-ups</h3>
      <a href="<?= e(site_url('zencp/topups.php')) ?>" class="text-xs text-primary font-semibold">View all →</a>
    </div>
    <?php if (!$recentTopups): ?>
      <div class="text-slate-500 text-sm text-center py-6">No top-up requests yet.</div>
    <?php else: ?>
      <div class="divide-y divide-white/5">
        <?php foreach ($recentTopups as $t):
          $col = ['pending'=>'bg-amber-500','approved'=>'bg-emerald-500','rejected'=>'bg-rose-500'][$t['status']] ?? 'bg-slate-500';
        ?>
          <div class="py-2.5 flex items-center gap-3 text-sm">
            <div class="flex-1 min-w-0">
              <div class="font-semibold truncate"><?= e($t['user_name']) ?> · <?= format_money($t['amount']) ?></div>
              <div class="text-xs text-slate-500">Via <?= e($t['method'] ?? '—') ?> · TxnID: <?= e($t['trx_id']) ?> · <?= time_ago($t['created_at']) ?></div>
            </div>
            <span class="pill <?= $col ?> text-white"><?= ucfirst($t['status']) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>
